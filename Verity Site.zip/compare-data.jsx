// compare-data.jsx — Compare feature: financial projection models + sample men
// Goal: rank a roster of men by risk-adjusted projected income at a chosen
// year-horizon, with honest confidence bands. Each archetype is modeled
// differently (founder = variance; attorney = deterministic; etc).

// ── Profile schema ──────────────────────────────────────────────────────
// Each profile carries an archetype, a current income, and a `project(year)`
// function that returns { expected, low, high } dollars/year for that year.
// `expected` is the risk-adjusted expected value. low/high define an 80%
// confidence band, drawn as fill behind the line in the chart.

const COMPARE_MEN = [
  {
    id: 'alex',
    name: 'Alex Pierre',
    age: 32,
    role: 'Founder · CEO',
    company: 'Stitch Labs · Seed, raising A',
    archetype: 'Tech founder',
    initials: 'AP',
    score: 'yellow',
    current: 95000,
    risk: 0.72,
    color: 'var(--rose)',
    colorDeep: 'var(--wine)',
    colorPale: 'var(--blush-pale)',
    summary: 'High variance. Two years of break-even runway, one Series A on the deck. If the A closes and the company exits, his trajectory bends sharply upward. If it doesn\'t, he returns to industry pay — comfortably, but with no founder upside.',
    notes: {
      5: 'Year 5 sits right on the A. Closed cleanly: ~$350K cash + meaningful equity. Walked away: $310K in an L6 role somewhere good.',
      10: 'A founder who shipped his second round is a materially different bet from one who didn\'t. Watch year 4 closely.',
      20: 'Founder math: 1 in 30 outcomes are life-changing, the other 29 are fine. Expected value is real, but the variance is the entire story.',
    },
    project: (y) => {
      const successProb = 0.28;
      let success;
      if (y < 4) success = 95000 * Math.pow(1.04, y);
      else if (y < 8) success = 95000 * Math.pow(1.04, 4) * Math.pow(1.45, y - 4);
      else if (y < 14) success = 95000 * Math.pow(1.04, 4) * Math.pow(1.45, 4) * Math.pow(1.18, y - 8);
      else success = Math.min(25000000, 95000 * Math.pow(1.04, 4) * Math.pow(1.45, 4) * Math.pow(1.18, 6) * Math.pow(1.05, y - 14));
      let failure;
      if (y < 4) failure = 95000 * Math.pow(1.05, y);
      else failure = 310000 * Math.pow(1.038, y - 4);
      const expected = success * successProb + failure * (1 - successProb);
      const high = Math.max(success, failure, expected);
      const low = Math.min(success, failure, expected);
      return { expected, high, low };
    },
  },
  {
    id: 'reid',
    name: 'Reid Whitman',
    age: 36,
    role: 'Corporate attorney',
    company: 'Cravath, Swaine & Moore · M&A',
    archetype: 'BigLaw partner-track',
    initials: 'RW',
    score: 'green',
    current: 325000,
    risk: 0.12,
    color: 'var(--mauve)',
    colorDeep: 'var(--plum-soft)',
    colorPale: 'var(--ivory-warm)',
    summary: 'Predictable, ceiling-bound. Partner track puts him at $1.1M ± $200K by year 5. Plateau begins around senior partner at year 15. Limited upside above $2.5M unless he opens his own shop — which corporate-M&A guys at white-shoe firms rarely do.',
    notes: {
      5: 'Partner at Cravath or one peer firm: $1.1M ± 200K. Steady, not stratospheric.',
      10: 'Senior partner band. Top of his pay scale. The plateau begins asserting itself.',
      20: 'No real upside from here without an entrepreneurial turn. Watch for the "of counsel" downshift in his 50s.',
    },
    project: (y) => {
      const partnerY = 4, seniorY = 15;
      let expected;
      if (y < partnerY) expected = 325000 + (1100000 - 325000) * (y / partnerY);
      else if (y < seniorY) expected = 1100000 + (1900000 - 1100000) * ((y - partnerY) / (seniorY - partnerY));
      else expected = 1900000 * Math.pow(1.006, y - seniorY);
      return { expected, high: expected * 1.18, low: expected * 0.84 };
    },
  },
  {
    id: 'marcus',
    name: 'Marcus Anderson',
    age: 41,
    role: 'Real estate operator',
    company: 'Anderson Holdings LLC',
    archetype: 'Cyclical operator',
    initials: 'MA',
    score: 'yellow',
    current: 260000,
    risk: 0.40,
    color: 'var(--honey)',
    colorDeep: 'var(--honey-deep)',
    colorPale: 'var(--honey-pale)',
    summary: 'Cyclical. Income tracks the property market — strong in good cycles, soft in down ones. The active 2024 civil suit caps near-term growth. No clear path above $1.5M without scaling the LLC into a real fund.',
    notes: {
      5: 'A 2027-2029 market does most of the work here. Expected: $360K, but the range is wide.',
      10: 'If he scales the LLC and weathers two cycles, $700K+ is plausible. If not, sideways.',
      20: 'Real estate operators in their 60s either own everything or own one thing too long. Watch the diversification carefully.',
    },
    project: (y) => {
      const base = 260000 + (1150000 - 260000) * Math.min(1, y / 16);
      const cycle = Math.sin(y / 3.2 + 1) * 70000;
      const expected = Math.max(180000, base + cycle);
      return { expected, high: expected * 1.75, low: expected * 0.55 };
    },
  },
  {
    id: 'daniel',
    name: 'Daniel Chen',
    age: 34,
    role: 'Senior Staff Engineer',
    company: 'Stripe · Infrastructure',
    archetype: 'Senior IC engineer',
    initials: 'DC',
    score: 'green',
    current: 375000,
    risk: 0.08,
    color: 'var(--sage)',
    colorDeep: 'var(--sage-deep)',
    colorPale: 'var(--sage-pale)',
    summary: 'Stable, capped. IC engineer ladders top out around Distinguished Engineer at ~$1.1M. Strong floor, modest ceiling. Liquidity comes from RSUs and the next round, not multiples. The boring number that compounds.',
    notes: {
      5: 'Principal Engineer band: $620K - $780K. Quiet, dependable growth.',
      10: 'Distinguished Engineer at $1M+, or a CTO pivot. The plateau asserts around year 12.',
      20: 'Without a founder turn or an executive pivot, this is the ceiling. The stability is the feature.',
    },
    project: (y) => {
      const expected = Math.min(1100000, 375000 * Math.pow(1.075, Math.min(y, 14))) * Math.pow(1.005, Math.max(0, y - 14));
      return { expected, high: expected * 1.14, low: expected * 0.90 };
    },
  },
];

// ── Helpers ─────────────────────────────────────────────────────────────
function fmtMoney(n) {
  if (n >= 1e9) return '$' + (n / 1e9).toFixed(1) + 'B';
  if (n >= 1e6) return '$' + (n / 1e6).toFixed(n >= 1e7 ? 0 : 1) + 'M';
  if (n >= 1e3) return '$' + Math.round(n / 1e3) + 'K';
  return '$' + Math.round(n);
}

function fmtMoneyShort(n) {
  if (n >= 1e6) return (n / 1e6).toFixed(n >= 1e7 ? 0 : 1) + 'M';
  if (n >= 1e3) return Math.round(n / 1e3) + 'K';
  return Math.round(n);
}

function fmtYearLabel(y) {
  if (y === 0) return 'today';
  if (y === 1) return '1 year out';
  return `${y} years out`;
}

// Log-scale Y axis: $50K → 0, $25M → 1
function logY(value) {
  const minLog = Math.log10(50000);
  const maxLog = Math.log10(25000000);
  const v = Math.max(50000, Math.min(25000000, value));
  return (Math.log10(v) - minLog) / (maxLog - minLog);
}

// Rank profiles by expected projected income at given year
function rankProfiles(profiles, year) {
  return [...profiles]
    .map(p => ({ ...p, _proj: p.project(year) }))
    .sort((a, b) => b._proj.expected - a._proj.expected);
}

window.COMPARE_MEN = COMPARE_MEN;
window.compareUtils = { fmtMoney, fmtMoneyShort, fmtYearLabel, logY, rankProfiles };
