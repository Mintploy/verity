# Handoff: Verity

> Private safety-intelligence app for women. Phone number in → full safety report out. Editorial-luxury aesthetic in **Bubblegum Gold** palette. Includes onboarding, ID verification, search, report, and a financial **Compare** feature for ranking multiple men by projected income.

---

## About these files

The files in `source/` are **design references**, not production code. They are HTML + inline JSX prototypes (compiled in-browser with Babel-standalone) that demonstrate the intended look, behavior, and copy of the product. They are deliberately not production-shape — they exist to be read like a spec.

**Your task:** Rebuild these designs in the target codebase using its existing conventions (React, Next.js, SwiftUI, etc.). If no codebase exists yet, **React + Vite + TypeScript** is the most natural target — every component here is already valid React JSX and would port cleanly.

**Do not ship this HTML directly.** It depends on in-browser Babel transpilation, has no build system, fetches React from a CDN, and uses CSS variables in a `tokens.css` file rather than a real design-system module.

## Fidelity

**Hi-fi.** Every screen has final colors, type, spacing, copy, and interactions. Reproduce pixel-for-pixel. Use the established component library of the target codebase for primitives (button, input, dialog) but match the visual treatment exactly.

---

## Files in this bundle

```
source/
├── tokens.css                       Design tokens (CSS variables)
├── index.html                       Design canvas — entry point that frames everything
├── mobile.html                      Mobile prototype shell (iOS frame + state machine)
├── desktop.html                     Desktop prototype shell (landing / report / compare)
├── palette-explorations.html        Reference: 6 alternate palette directions (Bubblegum Gold won)
│
├── petals.jsx                       Decorative SVG primitives (Wordmark, Floret, Sparkle, …)
│
├── mobile-screens-onboarding.jsx    Mobile screens: landing, verify, search, loading
├── mobile-report.jsx                Mobile report screen
├── mobile-compare.jsx               Mobile compare screen
├── mobile-data.jsx                  3 sample personas (green/yellow/red)
│
├── desktop-screens.jsx              Desktop landing page sections
├── desktop-report.jsx               Desktop report layout (3-column)
├── desktop-compare.jsx              Desktop compare layout with trajectory chart
├── compare-data.jsx                 Financial projection models + 4 sample men
│
├── ios-frame.jsx                    iOS device chrome (status bar, home indicator, keyboard)
├── design-canvas.jsx                Figma-style canvas wrapper (only for `index.html`)
└── tweaks-panel.jsx                 In-page tweak controls (only for prototypes; do not port)
```

---

## Design tokens — Bubblegum Gold

All values in `source/tokens.css`. Port these into your design-system module exactly.

### Color

| Token | Hex | Usage |
|---|---|---|
| `--ivory` | `#FFF4F4` | Page background (pink-tinted cream) |
| `--ivory-warm` | `#FFE0DE` | Card variant bg, warm surface |
| `--ivory-deep` | `#F5D0CE` | Divider, hover state |
| `--champagne` | `#F3E5C6` | Soft gold surface, ribbons |
| `--pearl` | `#FFFCF8` | Pure card background |
| `--primary` | `#FF4E8E` | **Primary CTA bg, electric pink accent (bubblegum)** |
| `--primary-deep` | `#B41E61` | Hover/pressed state, deep accent text, gradient anchor |
| `--primary-pale` | `#FFD2E0` | Soft pink surface, sticker bg |
| `--primary-mist` | `#FFE5EE` | Softest pink surface |
| `--blush` | `#FFD2E0` | Alias of --primary-pale (back-compat) |
| `--blush-deep` | `#FF4E8E` | Alias of --primary |
| `--blush-pale` | `#FFE5EE` | Alias of --primary-mist |
| `--rose` | `#E7506C` | Italic accent text |
| `--gold` | `#C9A66B` | Warm gold accent (badges, hairlines) — trust ballast |
| `--gold-pale` | `#F3E5C6` | Soft gold surface |
| `--gold-deep` | `#8A6E3A` | Deep gold text/icon |
| `--mauve` | `#C8A6B4` | Tertiary text |
| `--mauve-deep` | `#956D82` | Secondary muted text |
| `--plum` | `#2C0E26` | **Primary text — near-black berry** |
| `--plum-soft` | `#5C2A50` | Secondary text alt |
| `--wine` | `#B41E61` | Alias of --primary-deep |

### Score states (semantic — keep names)

| State | Bg | Pale | Deep |
|---|---|---|---|
| GREEN (proceed) | `--sage` `#87AE7E` | `--sage-pale` `#DEECD6` | `--sage-deep` `#2F4A2C` |
| YELLOW (go slow) | `--honey` `#E9B25C` | `--honey-pale` `#F9DCAA` | `--honey-deep` `#6E4F1D` |
| RED (skip) | `--deeprose` `#E7506C` | `--deeprose-pale` `#F8CAD2` | `--deeprose-deep` `#7A1E36` |

### Type

- **Display:** `Cormorant Garamond` (Google Font) — weights 300/400/500/600/700, with italics. Used for all headlines, score labels, decorative quotes. Italics carry semantic emphasis (always the "accent" word).
- **Body:** `Outfit` (Google Font) — weights 300/400/500/600/700. Used for body copy, UI labels, microcopy, eyebrows.
- **Logo only:** `Italiana` (Google Font) — used **only** for the `VERITY` wordmark with `letter-spacing: 0.08em`.

Type rules:
- Headlines use light weights (400) with letter-spacing -0.3 to -1.0
- Italic-accent pattern: a single word per headline rendered in italic + `--primary` color (e.g. *before* in "Know him *before* you meet him")
- Eyebrows: 11px, 500 weight, 0.22em letter-spacing, uppercase, `--mauve-deep`
- Body: 13-16px, 300/400 weight, line-height 1.5-1.65, `--plum` or `--plum-soft`

### Radii / shadow / spacing

| Token | Value | Usage |
|---|---|---|
| `--r-sm` | 10px | Small surfaces |
| `--r-md` | 18px | Inline cards |
| `--r-lg` | 28px | Section cards |
| `--r-xl` | 36px | Hero cards |
| `--r-pill` | 9999px | All pill buttons + stickers |
| `--shadow-xs` | `0 1px 2px rgba(44,14,38,0.04)` | Pill chips |
| `--shadow-sm` | `0 2px 8px rgba(44,14,38,0.06), 0 1px 2px rgba(44,14,38,0.03)` | Cards |
| `--shadow-md` | `0 8px 24px rgba(44,14,38,0.08), 0 2px 6px rgba(44,14,38,0.04)` | Floating cards |
| `--shadow-lg` | `0 24px 60px rgba(44,14,38,0.12), 0 8px 16px rgba(44,14,38,0.06)` | Hero peek card |
| `--shadow-pop` | `0 12px 40px rgba(255, 78, 142, 0.22)` | **Pink CTA buttons** |

Spacing: 8px base. Card padding generally 16–28px. Page gutters 56px desktop, 16–28px mobile.

---

## Screens

### Mobile (iOS, 402×874 frame)

1. **Landing** (`screen=landing`) — Wordmark top-left, "Sign in" link top-right. Hero: `+ for her, only` sticker, headline *Know him before you meet him.*, body copy, trust strip (avatar cluster + member count), bubblegum `Begin verification →` CTA, "Verified women only · ID required · Powered by Stripe" microcopy.
2. **Verify Intro** (`verifyIntro`) — Eyebrow `ONBOARDING · THE RITUAL`, italic headline *Welcome,* we'll take it from here.. Three numbered step cards (ID / Selfie / Welcome). Note from Verity about Stripe Identity. CTA *Begin verification →*.
3. **Verify ID** (`verifyId`) — `STEP ONE OF THREE` eyebrow, *A photo of your ID.* headline. Dashed ID-card frame with corner brackets + camera icon. 3-state: idle, scanning (animated horizontal sweep), done (sage check). CTA toggles between states.
4. **Verify Selfie** (`verifySelfie`) — `STEP TWO OF THREE`. Round selfie frame with concentric ring + pulse-ring animation. Big circular capture button with pulse animation. On capture: 1.8s "matching face to ID" then auto-advance.
5. **Verify Success** (`verifySuccess`) — Three drifting pink/champagne/sage blooms (float animation). Floret icon bloom-in animation. Sticker `✦ verified · member #47,232` in sage-pale. Headline *You're in.* CTA *Run your first search →*.
6. **Search** (`search`) — `NEW SEARCH` eyebrow, *Who would you like to know?* Two soft-cards: phone (required) and name (optional, italic placeholder). "Searches are private. *He'll never know.*" note. Recent searches row of pills + "compare them →" link. CTA *Get the report →*. "1 of 3 searches this week · upgrade for unlimited" microcopy.
7. **Loading** (`loading`) — Drifting blooms backdrop. Animated 6-petal rotating arrangement. Stage text cycling through six lines ("Reaching the carrier…", "Cross-referencing identity…", "Pulling property records…", "Checking public filings…", "Scanning social footprint…", "Sealing the envelope…"). Progress dots. Total ~4s before auto-advance.
8. **Report** (`report`) — See Report Schema below.
9. **Compare** (`compare`) — See Compare Schema below.

### Desktop (1440 design width, responsive)

1. **Landing** — Sticky glass nav (logo + 5 links + Compare italic pill + Sign in + bubblegum Begin verification). Hero: 2-col grid (1.1fr 1fr). Left: sticker, headline, body, search bar (phone input + Get the report →), trust strip. Right: floating sample-report peek card with stickers ("what we'd ask him", "generated in 14s"). Sections below: press strip (As featured in · 6 publications), How it works (3-card grid w/ 01/02/03), What you'll know (sticky-left 2-col grid of 8 numbered sections), centered testimonial, final CTA card (deep-pink → berry-black gradient), 4-column footer.
2. **Report** — 3-column grid (280px / 1fr / 320px). Left rail: Back, "Jump to" nav, recent searches list. Center: header row (report ID, *On Marcus Anderson*, generated meta), big score badge (2-col split: score on left, summary on right), 8 section cards in mixed 1-col/2-col grid, footer disclaimer. Right rail: sticky "Recommendations" gradient card with numbered next steps, action button stack (Compare with others, Download PDF, Share, Re-run in 30 days, Reverse-image), Verity's cardinal rule blockquote.
3. **Compare** — Header w/ headline *Where each of them actually lands.* Big horizon slider (300px label column showing big serif year + "years out" + "he'll be ~age on avg"; track with stops 1/3/5/10/15/20/30/40/50). 2-col layout below (1.2fr / 1.8fr): left ranked cards (avatar, name+role, projected income, ±range, sparkline, expandable Verity's read with stats), right sticky trajectory chart + dark verdict card (highest expected vs highest ceiling).

---

## Report schema (used in both mobile and desktop)

Score badge displays one of three states, each with paired label + sub-copy:

| Score | Label | Sub-copy |
|---|---|---|
| green | **Green light** | *Proceed with ease.* |
| yellow | **Soft yellow** | *Worth a slower pace.* |
| red | **Deep rose** | *We'd skip this one.* |

8 sections, each card has eyebrow `SECTION 0N`, title, icon, content:

1. **Phone intelligence** — Carrier, line type (with VoIP flag), number age, geographic origin
2. **Identity signals** — Full name, age, DOB, "Verified by 3 sources"
3. **Address history** — Last 5 addresses with year ranges, ownership/rental + price, current pin, eviction flags
4. **Relationships & marital** — Current status, spouse, prior marriages, relatives, close associates
5. **Professional profile** — Title, company, tenure, est. income, est. net worth, LLCs
6. **Public record flags** — Sex offender registry, bankruptcy, lawsuits, evictions, licenses, political donations (each marked good/flag/neutral)
7. **Social footprint** — Handles, presence assessment, inconsistency flags
8. **Recommended next steps** ("Your move") — Numbered 01-05, served on dark deep-pink→berry gradient card

3 sample personas live in `mobile-data.jsx`:
- **green**: Daniel Chen, 34, Stripe SSE — clean across all sections
- **yellow**: Marcus Anderson, 41, real estate — VoIP secondary line, one open civil suit, age inconsistency on X
- **red**: Brandon Reyes, 39, claimed sales director — VoIP primary, two evictions, Chapter 7 bankruptcy, active judgment

---

## Compare schema (financial projection)

Each of 4 sample men has a `project(year)` function returning `{ expected, high, low }` dollars at any year 1–50. Models live in `compare-data.jsx`.

| Profile | Archetype | Current | Model |
|---|---|---|---|
| **Alex Pierre** (32, founder) | Bimodal | $95K | 28% success path (exponential 1.45× → 1.18×), 72% failure path back to $310K industry baseline. Band shows both outcomes. |
| **Reid Whitman** (36, BigLaw) | Deterministic ramp + plateau | $325K | Linear to partner at year 4 ($1.1M), then to senior partner at year 15 ($1.9M), then plateau at 0.6% growth. ±18% band. |
| **Marcus Anderson** (41, real estate) | Cyclical | $260K | Trend to $1.15M over 16 years plus sinusoidal cycle ±$70K. Wide ±75/55% band. |
| **Daniel Chen** (34, Stripe SSE) | Capped exponential | $375K | 7.5% growth capped at $1.1M with 0.5% post-cap creep. Tight ±14/10% band. |

`rankProfiles(profiles, year)` sorts descending by expected. Chart uses log Y-axis ($50K → $25M).

---

## Interactions & behavior

- **State machine** drives mobile flow via a single `screen` string. Query params (`?screen=X&score=Y&chrome=none`) override defaults — useful for embedding screens in iframes.
- **Verify ID / Selfie** transitions are timed (2.2s scan, 1.8s match) for prototype purposes; in production these gate on real Stripe Identity callbacks.
- **Score state toggle** for the report is a demo affordance; production reports return a single score from the backend.
- **Compare slider** is a continuous pointer-capture range over years 1–50 with snap stops at 1/3/5/10/15/20/30/40/50.
- **Trajectory chart** supports drag-to-scrub the year cursor.
- **Verity's read** card expands in place with smooth height transition.

### Animations

- Verify success: petal float (8–12s loop), bloom scale-in (0.8s cubic-bezier(.3,1.4,.4,1)), fade-up sequence (.6s with .2s/.3s/.5s/.7s stagger)
- Loading: 12s spin on petal cluster, 6.5s stage cadence, drift loops 9–13s on bloom blobs
- Score pulse: dot box-shadow pulse (2.4s ease-in-out)
- ID scan: linear gradient sweep (2s loop top:12%↔75%)
- Selfie ring pulse: 2s ease-in-out box-shadow expansion
- Slider thumb: spring transition `cubic-bezier(.5,1.5,.4,1)` 0.35s

---

## Imagery & assets

- **No raster images.** All decoration is SVG (`petals.jsx` exports `Petal`, `Floret`, `Bloom`, `Sparkle`, `VMark`, `Wordmark`, `Swoosh`, `HandArrow`, `DotDivider`).
- **Avatars** are gradient circles with the subject's initials in italic serif — no real photos in this prototype.
- **Sample report peek** card is a hand-built composition, not a screenshot.

When implementing in production:
- Subject avatars should accept an optional `imageUrl`; fall back to the initials gradient.
- The floral motifs are part of the brand language — keep them as inline SVG components for easy color theming.

---

## State management notes

- Mobile prototype keeps `{ screen, score, phone, name }` in a single React `useState` at the app root.
- Desktop prototype splits `{ view, score }` similarly.
- Compare slider state (`year`) is local to the compare screen; the projection functions are pure (memoized via `useMemo`).
- The `tweaks-panel.jsx` system is **not for production** — it's a designer affordance for cycling through screens and score states in the prototype.

---

## Trust signals — preserve these

The brand promise is trust delivered via warmth, not clinical sterility. When porting, do not strip:

1. The **"Verified women only · ID required · Powered by Stripe"** microcopy under every primary CTA
2. The **sticker pill** signaling membership ("verified · member #47,232") in sage-pale
3. The **disclaimer** at the footer of every report (*"Verity does not predict the future. It tells you what's true today, so you can decide tomorrow."*)
4. The **cardinal-rule blockquote** on the desktop report ("Trust your gut. A clean report doesn't replace your read of him in person.")
5. The **Verity's read** italic commentary on every Compare card — the brand's first-person voice
6. The **sources line** in report footer (Whitepages Pro, ATTOM, BeenVerified, PACER, FEC, NSOPW, PDL)

---

## Tone of voice

Warm, intelligent, sisterly. Speaks directly to a woman who is smart, discerning, and done taking unnecessary risks. Copy feels like advice from a brilliant older sister who happens to have access to a private investigator. Always italicizes the emotional emphasis ("*before* you meet him", "where each of them *actually* lands"). Never clinical. Never alarmist.

---

## How to preview locally

The HTML files in `source/` work standalone. Open `source/index.html` in a modern browser to see the design canvas with all screens. Or open `source/mobile.html` / `source/desktop.html` directly. Tap the bottom-right Tweaks panel to switch screens and score states.
