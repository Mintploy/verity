// desktop-compare.jsx — Compare screen for desktop, wider with trajectory chart prominent

const { useState: useStateDC, useMemo: useMemoDC, useRef: useRefDC } = React;

function DesktopCompare({ onBack }) {
  const [year, setYear] = useStateDC(5);
  const [expanded, setExpanded] = useStateDC(null);
  const men = window.COMPARE_MEN;
  const { fmtMoney, fmtMoneyShort, rankProfiles, logY } = window.compareUtils;
  const ranked = useMemoDC(() => rankProfiles(men, year), [year]);

  return (
    <div data-screen-label="Verity Desktop / Compare" style={{ background: 'var(--ivory)', minHeight: '100vh' }}>
      <VNav onSearch={onBack} />

      <div style={{ maxWidth: 1480, margin: '0 auto', padding: '40px 56px 80px', position: 'relative' }}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', flexWrap: 'wrap', gap: 24, marginBottom: 36 }}>
          <div style={{ maxWidth: 720 }}>
            <button onClick={onBack} style={{
              display: 'flex', alignItems: 'center', gap: 6, padding: 0,
              border: 0, background: 'transparent', cursor: 'pointer',
              fontFamily: 'var(--sans)', fontSize: 13, color: 'var(--plum-soft)', marginBottom: 14,
              whiteSpace: 'nowrap',
            }}>
              ← Back to search
            </button>
            <div className="v-eyebrow" style={{ marginBottom: 12 }}>Your shortlist · {ranked.length} men · the honest math</div>
            <h1 style={{
              fontFamily: 'var(--serif)', fontSize: 64, lineHeight: 1.0, fontWeight: 400,
              color: 'var(--plum)', margin: 0, letterSpacing: -0.6, textWrap: 'balance',
            }}>
              Where each of them <span style={{ fontStyle: 'italic', color: 'var(--rose)' }}>actually</span> lands.
            </h1>
            <p style={{
              fontFamily: 'var(--sans)', fontSize: 16, color: 'var(--plum-soft)', lineHeight: 1.6,
              margin: '18px 0 0', maxWidth: 580, fontWeight: 300,
            }}>
              Each man modeled on his archetype — tech founder versus partner-track attorney versus cyclical operator versus capped IC. Risk-adjusted. Confidence bands shown. Slide the year and watch them re-rank.
            </p>
          </div>
          <Floret size={48} color="var(--blush-deep)" center="var(--ivory)"/>
        </div>

        {/* Year slider — desktop full-width */}
        <div style={{
          padding: '24px 28px', borderRadius: 'var(--r-xl)',
          background: 'var(--pearl)', boxShadow: 'var(--shadow-sm)', marginBottom: 32,
          display: 'grid', gridTemplateColumns: '300px 1fr', gap: 36, alignItems: 'center',
        }}>
          <div>
            <div className="v-eyebrow" style={{ fontSize: 10, marginBottom: 4 }}>Horizon</div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 12, lineHeight: 1 }}>
              <div style={{
                fontFamily: 'var(--serif)', fontSize: 88, lineHeight: 0.9, fontWeight: 400,
                color: 'var(--plum)', letterSpacing: -2, fontVariantNumeric: 'tabular-nums',
              }}>{year}</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                <div style={{ fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 22, color: 'var(--rose)', fontWeight: 300, whiteSpace: 'nowrap' }}>
                  {year === 1 ? 'year out' : 'years out'}
                </div>
                <div style={{ fontFamily: 'var(--sans)', fontSize: 11.5, color: 'var(--mauve-deep)', fontStyle: 'italic', whiteSpace: 'nowrap' }}>
                  he'll be ~{Math.round((year + 36))} on avg
                </div>
              </div>
            </div>
          </div>

          <BigSlider year={year} setYear={setYear}/>
        </div>

        {/* Two columns: ranked cards (left) + chart (right) */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1.8fr', gap: 28, alignItems: 'flex-start' }}>

          {/* Ranked column */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div className="v-eyebrow" style={{ marginBottom: 4 }}>Ranked · expected income at year {year}</div>
            {ranked.map((m, i) => (
              <DesktopCompareCard
                key={m.id}
                man={m}
                rank={i + 1}
                year={year}
                expanded={expanded === m.id}
                onToggle={() => setExpanded(expanded === m.id ? null : m.id)}
              />
            ))}
          </div>

          {/* Chart column */}
          <div style={{ position: 'sticky', top: 92, display: 'flex', flexDirection: 'column', gap: 20 }}>
            <DesktopTrajectoryChart men={men} year={year} setYear={setYear}/>

            {/* Quick stats */}
            <div style={{
              padding: '20px 22px', borderRadius: 'var(--r-lg)',
              background: 'linear-gradient(160deg, var(--primary-deep) 0%, var(--plum) 100%)',
              color: 'var(--ivory)', position: 'relative', overflow: 'hidden',
            }}>
              <div style={{
                position: 'absolute', top: -40, right: -40, width: 160, height: 160, borderRadius: '50%',
                background: 'radial-gradient(circle, var(--rose) 0%, transparent 65%)', opacity: 0.4,
              }}/>
              <div style={{ position: 'relative', zIndex: 1 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
                  <Floret size={18} color="var(--blush)" center="var(--wine)"/>
                  <div className="v-eyebrow" style={{ color: 'var(--blush)', fontSize: 10 }}>Verity's read</div>
                </div>
                <div style={{ fontFamily: 'var(--serif)', fontSize: 22, fontStyle: 'italic', lineHeight: 1.2, color: 'var(--blush)', fontWeight: 400 }}>
                  "At year {year}, {ranked[0].name.split(' ')[0]} leads — but the gap is largely a function of variance, not certainty. Watch the bands, not just the lines."
                </div>
                <div style={{ marginTop: 16, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                  <div>
                    <div className="v-eyebrow" style={{ color: 'var(--blush)', fontSize: 9.5, marginBottom: 2 }}>Highest expected</div>
                    <div style={{ fontFamily: 'var(--serif)', fontSize: 22, color: 'var(--ivory)', fontVariantNumeric: 'tabular-nums' }}>{fmtMoney(ranked[0]._proj.expected)}</div>
                    <div style={{ fontFamily: 'var(--sans)', fontSize: 11, color: 'var(--blush)', marginTop: 2 }}>{ranked[0].name}</div>
                  </div>
                  <div>
                    <div className="v-eyebrow" style={{ color: 'var(--blush)', fontSize: 9.5, marginBottom: 2 }}>Highest ceiling</div>
                    {(() => {
                      const ceiling = [...ranked].sort((a,b) => b._proj.high - a._proj.high)[0];
                      return (
                        <>
                          <div style={{ fontFamily: 'var(--serif)', fontSize: 22, color: 'var(--ivory)', fontVariantNumeric: 'tabular-nums' }}>{fmtMoney(ceiling._proj.high)}</div>
                          <div style={{ fontFamily: 'var(--sans)', fontSize: 11, color: 'var(--blush)', marginTop: 2 }}>{ceiling.name}</div>
                        </>
                      );
                    })()}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer note */}
        <div style={{ textAlign: 'center', marginTop: 60, padding: '24px 0' }}>
          <DotDivider width={180} color="var(--mauve)" style={{ display: 'block', margin: '0 auto' }}/>
          <div style={{
            marginTop: 18, fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 18, color: 'var(--plum-soft)',
            lineHeight: 1.5, maxWidth: 640, margin: '18px auto 0', textWrap: 'balance',
          }}>
            Income is one signal. The right partner isn't always the highest projection — sometimes the steadiest line is the right one. But you deserve to make the call with both eyes open.
          </div>
          <div style={{
            marginTop: 14, fontFamily: 'var(--sans)', fontSize: 11, color: 'var(--mauve-deep)', letterSpacing: 0.3, lineHeight: 1.6,
          }}>
            Modeled from BLS occupational data, archetype priors, public-record file on each subject · 80% confidence bands shown · projections are expected values, not promises
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Big slider (desktop) ────────────────────────────────────────────────
function BigSlider({ year, setYear }) {
  const trackRef = useRefDC(null);
  const [dragging, setDragging] = useStateDC(false);
  const stops = [1, 3, 5, 10, 15, 20, 30, 40, 50];

  const handleMove = (clientX) => {
    if (!trackRef.current) return;
    const rect = trackRef.current.getBoundingClientRect();
    const pct = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
    setYear(Math.max(1, Math.round(1 + pct * 49)));
  };
  const pct = (year - 1) / 49;

  return (
    <div>
      <div
        ref={trackRef}
        onPointerDown={(e) => { setDragging(true); e.currentTarget.setPointerCapture(e.pointerId); handleMove(e.clientX); }}
        onPointerMove={(e) => { if (dragging) handleMove(e.clientX); }}
        onPointerUp={(e) => { setDragging(false); e.currentTarget.releasePointerCapture(e.pointerId); }}
        style={{ position: 'relative', height: 44, padding: '18px 0', cursor: 'pointer', touchAction: 'none' }}
      >
        <div style={{
          position: 'absolute', left: 0, right: 0, top: '50%', height: 6,
          transform: 'translateY(-50%)', borderRadius: 3, background: 'var(--ivory-deep)',
        }}/>
        <div style={{
          position: 'absolute', left: 0, top: '50%', height: 6,
          transform: 'translateY(-50%)', borderRadius: 3,
          width: `${pct * 100}%`,
          background: 'linear-gradient(90deg, var(--blush) 0%, var(--rose) 100%)',
        }}/>
        {stops.map(s => {
          const sp = (s - 1) / 49;
          return (
            <div key={s} style={{
              position: 'absolute', left: `${sp * 100}%`, top: '50%',
              transform: 'translate(-50%, -50%)',
              width: 4, height: 14, borderRadius: 2,
              background: s <= year ? 'var(--rose)' : 'var(--mauve)',
              opacity: s === year ? 0 : 0.55,
            }}/>
          );
        })}
        <div style={{
          position: 'absolute', left: `${pct * 100}%`, top: '50%',
          transform: 'translate(-50%, -50%)',
          width: 36, height: 36, borderRadius: '50%',
          background: 'var(--ivory)',
          boxShadow: '0 6px 20px rgba(217,137,124,0.4), inset 0 0 0 2.5px var(--rose)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          cursor: 'grab',
        }}>
          <div style={{ width: 14, height: 14, borderRadius: '50%', background: 'var(--rose)' }}/>
        </div>
      </div>
      <div style={{ position: 'relative', height: 22, marginTop: 6 }}>
        {stops.map(s => {
          const sp = (s - 1) / 49;
          return (
            <button key={s} onClick={() => setYear(s)} style={{
              position: 'absolute', left: `${sp * 100}%`, transform: 'translateX(-50%)',
              border: 0, background: 'transparent', padding: '4px 6px', cursor: 'pointer',
              fontFamily: 'var(--sans)', fontSize: 12, color: s === year ? 'var(--rose)' : 'var(--mauve-deep)',
              fontWeight: s === year ? 600 : 400, letterSpacing: 0.3,
            }}>
              {s}y
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ── Desktop card ────────────────────────────────────────────────────────
function DesktopCompareCard({ man, rank, year, expanded, onToggle }) {
  const { fmtMoney } = window.compareUtils;
  const proj = man.project(year);
  const todayProj = man.project(0);
  const multiplier = proj.expected / todayProj.expected;
  const confRange = Math.abs(proj.high - proj.low) / 2 / proj.expected * 100;

  // Sparkline
  const points = useMemoDC(() => {
    const yrs = Array.from({ length: 26 }, (_, i) => i * 2);
    const vals = yrs.map(y => Math.log10(Math.max(50000, man.project(y).expected)));
    const minV = Math.min(...vals), maxV = Math.max(...vals);
    const range = maxV - minV || 1;
    return yrs.map((y, i) => ({ x: (y / 50) * 100, yv: 100 - ((vals[i] - minV) / range) * 100 }));
  }, [man]);
  const sparkPath = points.map((p, i) => `${i ? 'L' : 'M'}${p.x.toFixed(2)},${p.yv.toFixed(2)}`).join(' ');
  const cursorX = (year / 50) * 100;
  const cursorPoint = points.find(p => p.x >= cursorX) || points[points.length - 1];

  const milestoneKeys = [5, 10, 20];
  const closestKey = milestoneKeys.reduce((acc, k) => Math.abs(k - year) < Math.abs(acc - year) ? k : acc, 5);
  const commentary = man.notes[closestKey];

  const rankBg = rank === 1 ? 'var(--blush)' : rank === 2 ? 'var(--champagne)' : rank === 3 ? 'var(--ivory-warm)' : 'var(--ivory-deep)';
  const rankColor = rank === 1 ? 'var(--wine)' : 'var(--plum)';

  return (
    <div style={{
      borderRadius: 'var(--r-lg)', background: 'var(--pearl)', boxShadow: 'var(--shadow-sm)',
      overflow: 'hidden',
      border: rank === 1 ? `1.5px solid ${man.color}55` : '1px solid transparent',
    }}>
      <div style={{ padding: '18px 20px 16px', display: 'flex', alignItems: 'center', gap: 16 }}>
        <div style={{
          width: 44, height: 44, borderRadius: '50%', background: rankBg, color: rankColor,
          display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
          fontFamily: 'var(--serif)', fontSize: 24, fontStyle: 'italic',
          boxShadow: rank === 1 ? '0 0 0 3px var(--blush-pale)' : 'none',
        }}>{rank}</div>

        <div style={{
          width: 48, height: 48, borderRadius: '50%',
          background: `linear-gradient(135deg, ${man.colorPale}, ${man.color})`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: 'var(--serif)', fontSize: 18, fontStyle: 'italic', color: 'var(--plum)',
          flexShrink: 0, boxShadow: 'inset 0 0 0 1px var(--ivory-deep)',
        }}>{man.initials}</div>

        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: 'var(--serif)', fontSize: 22, color: 'var(--plum)', lineHeight: 1.1, fontWeight: 400, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
            {man.name}
          </div>
          <div style={{ fontFamily: 'var(--sans)', fontSize: 12, color: 'var(--plum-soft)', marginTop: 4, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
            {man.role} · <span style={{ fontStyle: 'italic', fontFamily: 'var(--serif)', fontSize: 13 }}>{man.archetype}</span>
          </div>
        </div>

        <div style={{ textAlign: 'right', flexShrink: 0 }}>
          <div style={{ fontFamily: 'var(--serif)', fontSize: 28, fontWeight: 400, color: 'var(--plum)', lineHeight: 1, letterSpacing: -0.4, fontVariantNumeric: 'tabular-nums' }}>
            {fmtMoney(proj.expected)}
          </div>
          <div className="v-eyebrow" style={{ fontSize: 9.5, color: man.colorDeep, marginTop: 4 }}>
            ±{Math.round(confRange)}% range
          </div>
        </div>
      </div>

      <div style={{ padding: '0 20px 14px' }}>
        <svg viewBox="0 0 100 36" width="100%" height="36" preserveAspectRatio="none" style={{ display: 'block' }}>
          <line x1="0" y1="60%" x2="100" y2="60%" stroke="var(--ivory-deep)" strokeWidth="0.3" strokeDasharray="1 1" vectorEffect="non-scaling-stroke"/>
          <path d={sparkPath} fill="none" stroke={man.color} strokeWidth="1.8" vectorEffect="non-scaling-stroke" strokeLinecap="round" strokeLinejoin="round"/>
          <line x1={cursorX} y1="0" x2={cursorX} y2="36" stroke="var(--rose)" strokeWidth="1" strokeDasharray="2 2" vectorEffect="non-scaling-stroke" opacity="0.7"/>
          <circle cx={cursorX} cy={cursorPoint.yv} r="3" fill={man.color} stroke="var(--ivory)" strokeWidth="1.2" vectorEffect="non-scaling-stroke"/>
        </svg>
      </div>

      <div style={{ borderTop: '1px solid var(--ivory-deep)' }}>
        <button onClick={onToggle} style={{
          width: '100%', padding: '12px 20px', background: 'transparent', border: 0, cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        }}>
          <span className="v-eyebrow" style={{ fontSize: 10 }}>Verity's read</span>
          <span style={{ fontSize: 14, transform: expanded ? 'rotate(180deg)' : 'rotate(0)', transition: 'transform .2s', color: 'var(--mauve-deep)' }}>⌄</span>
        </button>
        {expanded && (
          <div style={{ padding: '0 20px 18px' }}>
            <div style={{
              padding: '14px 16px', background: 'var(--ivory)', borderRadius: 'var(--r-md)',
              fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 15, color: 'var(--plum)',
              lineHeight: 1.55,
            }}>
              "{commentary}"
            </div>
            <div style={{ marginTop: 10, padding: '14px 16px', background: 'var(--ivory-warm)', borderRadius: 'var(--r-md)' }}>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
                <Mini label="Today" value={fmtMoney(todayProj.expected)}/>
                <Mini label={`Y${year} expected`} value={fmtMoney(proj.expected)} accent={man.colorDeep}/>
                <Mini label="Multiple" value={`${multiplier.toFixed(1)}×`}/>
                <Mini label="Y50 ceiling" value={fmtMoney(man.project(50).high)}/>
              </div>
              <div style={{ marginTop: 14, fontFamily: 'var(--sans)', fontSize: 13, color: 'var(--plum-soft)', lineHeight: 1.55, fontWeight: 300 }}>
                {man.summary}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Desktop trajectory chart ────────────────────────────────────────────
function DesktopTrajectoryChart({ men, year, setYear }) {
  const { fmtMoney, logY } = window.compareUtils;
  const W = 100, H = 100;
  const points = useMemoDC(() => men.map(m => ({
    man: m,
    pts: Array.from({ length: 51 }, (_, y) => {
      const p = m.project(y);
      return {
        y, x: (y / 50) * W,
        yPx: (1 - logY(p.expected)) * H,
        yPxHigh: (1 - logY(p.high)) * H,
        yPxLow: (1 - logY(p.low)) * H,
      };
    }),
  })), [men]);
  const path = (pts) => pts.map((p, i) => `${i ? 'L' : 'M'}${p.x.toFixed(2)},${p.yPx.toFixed(2)}`).join(' ');
  const band = (pts) => `M${pts.map(p => `${p.x.toFixed(2)},${p.yPxHigh.toFixed(2)}`).join(' L')} L${[...pts].reverse().map(p => `${p.x.toFixed(2)},${p.yPxLow.toFixed(2)}`).join(' L')} Z`;

  const cursorX = (year / 50) * W;
  const yTicks = [100000, 500000, 1000000, 5000000, 25000000];
  const xTicks = [0, 5, 10, 15, 20, 30, 40, 50];

  const svgRef = useRefDC(null);
  const chartH = 340;
  const onPointer = (e) => {
    const rect = svgRef.current.getBoundingClientRect();
    const pct = (e.clientX - rect.left) / rect.width;
    setYear(Math.max(1, Math.min(50, Math.round(pct * 50))));
  };

  return (
    <div style={{
      padding: '28px 28px 24px', borderRadius: 'var(--r-xl)',
      background: 'var(--pearl)', boxShadow: 'var(--shadow-sm)',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 22 }}>
        <div>
          <div className="v-eyebrow" style={{ fontSize: 10, marginBottom: 6 }}>50-year trajectories</div>
          <div style={{ fontFamily: 'var(--serif)', fontSize: 28, color: 'var(--plum)', lineHeight: 1, fontWeight: 400 }}>
            Side by side, <span style={{ fontStyle: 'italic', color: 'var(--rose)' }}>compounded</span>.
          </div>
        </div>
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', justifyContent: 'flex-end' }}>
          {men.map(m => (
            <span key={m.id} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <span style={{ width: 10, height: 10, borderRadius: '50%', background: m.color }}/>
              <span style={{ fontFamily: 'var(--sans)', fontSize: 12, color: 'var(--plum)', whiteSpace: 'nowrap' }}>{m.name.split(' ')[0]}</span>
            </span>
          ))}
        </div>
      </div>

      <div style={{ position: 'relative', height: chartH }}>
        <div style={{ position: 'absolute', left: 0, top: 0, bottom: 24, width: 60 }}>
          {yTicks.map(v => {
            const yp = (1 - logY(v)) * (chartH - 24);
            return (
              <div key={v} style={{
                position: 'absolute', top: yp, left: 0, transform: 'translateY(-50%)',
                fontFamily: 'var(--sans)', fontSize: 11, color: 'var(--mauve-deep)', letterSpacing: 0.3,
                fontVariantNumeric: 'tabular-nums',
              }}>{fmtMoney(v)}</div>
            );
          })}
        </div>

        <svg
          ref={svgRef}
          viewBox={`0 0 ${W} ${H}`}
          width="100%" height={chartH - 24}
          preserveAspectRatio="none"
          style={{ display: 'block', marginLeft: 60, width: 'calc(100% - 60px)', cursor: 'col-resize', touchAction: 'none' }}
          onPointerDown={(e) => { e.currentTarget.setPointerCapture(e.pointerId); onPointer(e); }}
          onPointerMove={(e) => { if (e.buttons || e.pointerType === 'touch') onPointer(e); }}
        >
          {yTicks.map(v => {
            const yp = (1 - logY(v)) * H;
            return <line key={v} x1="0" y1={yp} x2={W} y2={yp} stroke="var(--ivory-deep)" strokeWidth="0.2" vectorEffect="non-scaling-stroke"/>;
          })}
          {xTicks.map(y => {
            const xp = (y / 50) * W;
            return <line key={y} x1={xp} y1="0" x2={xp} y2={H} stroke="var(--ivory-deep)" strokeWidth="0.2" vectorEffect="non-scaling-stroke" strokeDasharray="1 1.5"/>;
          })}
          {points.map(({ man, pts }) => (
            <path key={man.id + '-band'} d={band(pts)} fill={man.color} opacity="0.11"/>
          ))}
          {points.map(({ man, pts }) => (
            <path key={man.id} d={path(pts)} fill="none" stroke={man.color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke"/>
          ))}
          <line x1={cursorX} y1="0" x2={cursorX} y2={H} stroke="var(--plum)" strokeWidth="1" strokeDasharray="2 2" vectorEffect="non-scaling-stroke"/>
          {points.map(({ man, pts }) => {
            const p = pts[year] || pts[pts.length - 1];
            return <circle key={man.id + '-cur'} cx={cursorX} cy={p.yPx} r="2.6" fill={man.color} stroke="var(--ivory)" strokeWidth="1.2" vectorEffect="non-scaling-stroke"/>;
          })}
        </svg>

        {/* Cursor labels at cursor — value pill */}
        <div style={{ position: 'absolute', left: `calc(60px + ${(year / 50) * (100)}% - ${60 / (svgRef.current?.offsetWidth || 600) * 60}px)`, top: 0, bottom: 24, pointerEvents: 'none' }}>
          {/* tooltip removed for cleanliness */}
        </div>

        <div style={{ position: 'absolute', left: 60, right: 0, bottom: 0, height: 22 }}>
          {xTicks.map(y => {
            const xp = (y / 50) * 100;
            return (
              <div key={y} style={{
                position: 'absolute', left: `${xp}%`, transform: 'translateX(-50%)',
                fontFamily: 'var(--sans)', fontSize: 11, color: y === year ? 'var(--rose)' : 'var(--mauve-deep)', letterSpacing: 0.3, fontWeight: y === year ? 600 : 400,
              }}>
                {y === 0 ? 'now' : `${y}y`}
              </div>
            );
          })}
        </div>
      </div>

      <div style={{ marginTop: 12, fontFamily: 'var(--sans)', fontSize: 12, color: 'var(--mauve-deep)', lineHeight: 1.5, fontStyle: 'italic' }}>
        Faded bands show 80% confidence range · log y-axis · drag to scrub the year
      </div>
    </div>
  );
}

window.DesktopCompare = DesktopCompare;
