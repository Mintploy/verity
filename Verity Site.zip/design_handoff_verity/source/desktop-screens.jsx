// desktop-screens.jsx — Verity desktop landing + report

const { useState: useStateD, useEffect: useEffectD } = React;

// ── Verity launch URLs / nav targets ────────────────────────────────────
const VERIFY_URL = 'https://payment.verityprive.com';
const CONTACT_EMAIL = 'mailto:verity@mintploy.com';
const NAV_LINKS = [
  { label: 'Home', href: '#top' },
  { label: 'How it works', href: '#how-it-works' },
  { label: 'Stories', href: '#stories' },
  { label: 'Trust & safety', href: '#trust' },
  { label: 'Help', href: CONTACT_EMAIL },
];

// ── Desktop Nav ─────────────────────────────────────────────────────────
function VNav({ active = 'home', onSearch, onCompare }) {
  return (
    <nav style={{
      position: 'sticky', top: 0, zIndex: 50,
      padding: '20px 56px',
      background: 'rgba(250, 246, 240, 0.75)',
      backdropFilter: 'blur(20px) saturate(180%)',
      borderBottom: '1px solid var(--ivory-deep)',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between'
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 36 }}>
        <Wordmark size={26} color="var(--plum)" />
        <div style={{ display: 'flex', gap: 28, alignItems: 'center' }}>
          {NAV_LINKS.map(({ label, href }) =>
          <a key={label} href={href} style={{
            fontFamily: 'var(--sans)', fontSize: 13.5, color: 'var(--plum-soft)',
            textDecoration: 'none', letterSpacing: 0.2, whiteSpace: 'nowrap'
          }}>{label}</a>
          )}
          {onCompare &&
          <button onClick={onCompare} style={{
            display: 'inline-flex', alignItems: 'center', gap: 6,
            padding: '5px 12px', borderRadius: 'var(--r-pill)',
            background: 'var(--blush-pale)', color: 'var(--wine)',
            border: 0, cursor: 'pointer',
            fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 14, fontWeight: 500,
            whiteSpace: 'nowrap'
          }}>
              <Sparkle size={9} color="var(--wine)" />
              Compare
            </button>
          }
        </div>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
        <a href={VERIFY_URL} style={{ fontFamily: 'var(--sans)', fontSize: 13.5, color: 'var(--plum-soft)', textDecoration: 'none', whiteSpace: 'nowrap' }}>Sign in</a>
        <a href={VERIFY_URL} style={{
          padding: '10px 22px', borderRadius: 'var(--r-pill)',
          background: 'var(--primary)', color: 'var(--ivory)',
          border: 'none', cursor: 'pointer', textDecoration: 'none',
          fontFamily: 'var(--serif)', fontSize: 15, letterSpacing: 0.3,
          fontWeight: 500, whiteSpace: 'nowrap',
          boxShadow: 'var(--shadow-pop)', display: 'inline-block'
        }}>
          Begin <span style={{ fontStyle: 'italic', fontWeight: 300 }}>verification</span>
        </a>
      </div>
    </nav>);

}

// ── Hero ───────────────────────────────────────────────────────────────
function DesktopHero({ onSearch }) {
  const [phone, setPhone] = useStateD('');
  return (
    <section style={{ position: 'relative', padding: '80px 56px 60px', overflow: 'hidden' }}>
      {/* Decorative blooms */}
      <div style={{ position: 'absolute', top: -100, right: -150, width: 500, height: 500,
        background: 'radial-gradient(circle, var(--blush) 0%, transparent 65%)', opacity: 0.5 }} />
      <div style={{ position: 'absolute', top: 200, left: -80, width: 300, height: 300,
        background: 'radial-gradient(circle, var(--champagne) 0%, transparent 70%)', opacity: 0.5 }} />

      <div style={{ display: 'grid', gridTemplateColumns: '1.1fr 1fr', gap: 80, alignItems: 'center', position: 'relative', zIndex: 1, maxWidth: 1280, margin: '0 auto' }}>
        {/* Left: copy */}
        <div>
          <span className="v-sticker" style={{ marginBottom: 28 }}>
            <Sparkle size={11} color="var(--wine)" /> private intelligence, for her
          </span>

          <h1 style={{
            fontFamily: 'var(--serif)', fontSize: 88, lineHeight: 0.95, fontWeight: 400,
            color: 'var(--plum)', margin: 0, letterSpacing: -1.2, textWrap: 'balance'
          }}>
            Know him<br />
            <span style={{ fontStyle: 'italic', color: 'var(--rose)', fontWeight: 300 }}>before</span>
            {' '}you<br />
            meet him<span style={{ color: 'var(--rose)' }}>.</span>
          </h1>

          <p style={{
            fontFamily: 'var(--sans)', fontSize: 19, lineHeight: 1.55, color: 'var(--plum-soft)',
            margin: '36px 0 0', maxWidth: 480, fontWeight: 300
          }}>
            Verity is private intelligence for the woman who's done taking unnecessary risks. Drop in a phone number. Get back the full picture — quietly, in seconds.
          </p>

          {/* Hero search bar */}
          <div style={{
            marginTop: 36, padding: 8,
            background: 'var(--pearl)', borderRadius: 'var(--r-pill)',
            boxShadow: 'var(--shadow-lg)',
            display: 'flex', alignItems: 'center', gap: 8,
            maxWidth: 520
          }}>
            <div style={{ display: 'flex', alignItems: 'center', padding: '0 20px', flex: 1, minWidth: 0 }}>
              <span style={{ fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 16, color: 'var(--mauve-deep)', marginRight: 12, whiteSpace: 'nowrap' }}>His number</span>
              <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="(•••) ••• ••••"
              style={{
                flex: 1, border: 'none', background: 'transparent', outline: 'none',
                fontFamily: 'var(--serif)', fontSize: 22, color: 'var(--plum)',
                fontVariantNumeric: 'tabular-nums'
              }} />
            </div>
            <a href={VERIFY_URL} style={{
              padding: '16px 28px', borderRadius: 'var(--r-pill)',
              background: 'var(--primary)', color: 'var(--ivory)', border: 'none', cursor: 'pointer',
              fontFamily: 'var(--serif)', fontSize: 17, fontWeight: 500,
              display: 'flex', alignItems: 'center', gap: 6,
              whiteSpace: 'nowrap', textDecoration: 'none',
              boxShadow: 'var(--shadow-pop)'
            }}>
              Get the report <span style={{ fontStyle: 'italic', fontWeight: 300, marginLeft: 2 }}>→</span>
            </a>
          </div>
          <div style={{ fontFamily: 'var(--sans)', fontSize: 12.5, color: 'var(--mauve-deep)', marginTop: 16, letterSpacing: 0.3 }}>
            Verified women only · Your search stays private · He'll never know
          </div>

          {/* Trust strip */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 24, marginTop: 36 }}>
            <div style={{ display: 'flex' }}>
              {['var(--blush-deep)', 'var(--champagne)', 'var(--mauve)', 'var(--sage)', 'var(--rose)'].map((c, i) =>
              <div key={i} style={{
                width: 32, height: 32, borderRadius: '50%', background: c,
                border: '2.5px solid var(--ivory)', marginLeft: i ? -10 : 0
              }} />
              )}
            </div>
            <div style={{ fontFamily: 'var(--sans)', fontSize: 13.5, color: 'var(--plum-soft)', lineHeight: 1.4 }}>
              <span style={{ fontWeight: 600, color: 'var(--plum)' }}>47,232 women</span> already verified ·{' '}
              <span style={{ fontStyle: 'italic', fontFamily: 'var(--serif)', fontSize: 15 }}>her circle</span>
            </div>
          </div>
        </div>

        {/* Right: sample report peek */}
        <div style={{ position: 'relative' }}>
          <SampleReportPeek />
        </div>
      </div>
    </section>);

}

// Sample report card mockup floating in hero
function SampleReportPeek() {
  return (
    <div style={{ position: 'relative', maxWidth: 460, marginLeft: 'auto' }}>
      {/* Stacked cards effect */}
      <div style={{
        position: 'absolute', inset: 0, transform: 'translate(16px, 16px) rotate(2deg)',
        background: 'var(--ivory-warm)', borderRadius: 'var(--r-xl)',
        boxShadow: 'var(--shadow-md)'
      }} />
      <div style={{
        position: 'absolute', inset: 0, transform: 'translate(8px, 8px) rotate(1deg)',
        background: 'var(--champagne)', opacity: 0.6, borderRadius: 'var(--r-xl)'
      }} />

      <div style={{
        position: 'relative', borderRadius: 'var(--r-xl)',
        background: 'var(--pearl)', padding: 28,
        boxShadow: 'var(--shadow-lg)'
      }}>
        {/* Mini score badge */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 22 }}>
          <span className="v-eyebrow" style={{ fontSize: 10 }}>Sample report</span>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 12px', borderRadius: 'var(--r-pill)', background: 'var(--honey-pale)' }}>
            <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--honey-deep)' }} />
            <span style={{ fontFamily: 'var(--sans)', fontSize: 11, color: 'var(--honey-deep)', fontWeight: 500, letterSpacing: 0.3 }}>Soft yellow</span>
          </div>
        </div>

        <div style={{
          padding: '20px 22px', background: 'var(--honey-pale)', borderRadius: 'var(--r-lg)',
          marginBottom: 18
        }}>
          <div style={{ fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 22, color: 'var(--honey-deep)', lineHeight: 1.15 }}>
            "A few things to weigh."
          </div>
          <p style={{ fontFamily: 'var(--sans)', fontSize: 13, color: 'var(--plum)', margin: '8px 0 0', lineHeight: 1.55, fontWeight: 300 }}>
            Marcus is who he says he is — but the file isn't spotless. A secondary VoIP line on his identity, and one open civil matter, warrant a slower pace.
          </p>
        </div>

        {/* Subject row */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 18 }}>
          <div style={{
            width: 48, height: 48, borderRadius: '50%',
            background: 'linear-gradient(135deg, var(--ivory-warm), var(--champagne))',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: 'var(--serif)', fontStyle: 'italic', color: 'var(--plum-soft)'
          }}>MA</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: 'var(--serif)', fontSize: 18, color: 'var(--plum)' }}>Marcus Anderson</div>
            <div style={{ fontFamily: 'var(--sans)', fontSize: 11.5, color: 'var(--plum-soft)' }}>Age 41 · Scottsdale, AZ · (415) 555-0142</div>
          </div>
        </div>

        {/* Highlighted findings */}
        <div className="v-eyebrow" style={{ fontSize: 10, marginBottom: 10 }}>Key findings · 3 of 7 sections</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {[
          { label: 'Phone', val: 'T-Mobile · 3 years', flag: false },
          { label: 'Public records', val: '1 open civil suit · 2024', flag: true },
          { label: 'Social', val: 'Age discrepancy on X', flag: true }].
          map((r, i) =>
          <div key={i} style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            padding: '11px 14px', background: 'var(--ivory)', borderRadius: 'var(--r-md)'
          }}>
              <div className="v-eyebrow" style={{ fontSize: 9.5, color: 'var(--mauve-deep)' }}>{r.label}</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                {r.flag && <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--honey-deep)' }} />}
                <span style={{ fontFamily: 'var(--sans)', fontSize: 12.5, color: 'var(--plum)' }}>{r.val}</span>
              </div>
            </div>
          )}
        </div>

        <div style={{
          marginTop: 18, padding: '12px 14px',
          background: 'var(--ivory-warm)', borderRadius: 'var(--r-md)',
          fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 13.5, color: 'var(--plum)', lineHeight: 1.5
        }}>
          "Go in with eyes open, ask about the lawsuit, daytime first meeting."
          <div style={{ fontFamily: 'var(--sans)', fontStyle: 'normal', fontSize: 10.5, color: 'var(--mauve-deep)', marginTop: 6, letterSpacing: 0.3 }}>VERITY'S RECOMMENDATION</div>
        </div>
      </div>

      {/* Floating pill — "she said yes" decorative */}
      <div style={{
        position: 'absolute', top: -16, left: -28,
        padding: '8px 16px', background: 'var(--blush)',
        borderRadius: 'var(--r-pill)', boxShadow: 'var(--shadow-md)',
        fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 14, color: 'var(--wine)',
        transform: 'rotate(-6deg)'
      }}>
        what we'd ask him
      </div>

      <div style={{
        position: 'absolute', bottom: 24, right: -36,
        padding: '8px 14px', background: 'var(--pearl)',
        borderRadius: 'var(--r-pill)', boxShadow: 'var(--shadow-md)',
        fontFamily: 'var(--sans)', fontSize: 11, color: 'var(--plum)',
        transform: 'rotate(4deg)',
        display: 'flex', alignItems: 'center', gap: 6
      }}>
        <Sparkle size={10} color="var(--rose)" />
        <span>generated in 14s</span>
      </div>
    </div>);

}

// ── Strip: as featured in ────────────────────────────────────────────────
function PressStrip() {
  const press = ['Vogue', 'The Cut', 'Refinery29', 'Goop', 'New York Times', 'Bustle'];
  return (
    <section style={{
      borderTop: '1px solid var(--ivory-deep)', borderBottom: '1px solid var(--ivory-deep)',
      padding: '24px 56px', background: 'var(--ivory-warm)'
    }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 40, maxWidth: 1280, margin: '0 auto' }}>
        <span className="v-eyebrow" style={{ color: 'var(--plum-soft)' }}>As featured in</span>
        {press.map((p) =>
        <span key={p} style={{
          fontFamily: 'var(--serif)', fontSize: 22, color: 'var(--plum)',
          opacity: 0.7, letterSpacing: 0.5
        }}>{p}</span>
        )}
      </div>
    </section>);

}

// ── How it works ─────────────────────────────────────────────────────────
function HowItWorks() {
  const steps = [
  {
    num: '01',
    title: 'Verify yourself, once',
    body: 'A 90-second ID check (Stripe Identity). Verity is exclusively for women. The gate exists so the room stays safe.',
    accent: 'var(--blush-pale)'
  },
  {
    num: '02',
    title: 'Drop in a number',
    body: 'His phone is the only thing we truly need. A name sharpens the picture. He will never know you searched.',
    accent: 'var(--champagne)'
  },
  {
    num: '03',
    title: 'Read the room',
    body: 'A score, a verdict, and seven sections of cross-referenced public record. Plus what we\'d do next, in your shoes.',
    accent: 'var(--sage-pale)'
  }];


  return (
    <section id="how-it-works" style={{ padding: '120px 56px', position: 'relative', scrollMarginTop: 80 }}>
      <div style={{ maxWidth: 1280, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 60 }}>
          <div>
            <span className="v-eyebrow" style={{ marginBottom: 14, display: 'block' }}>How it works</span>
            <h2 style={{
              fontFamily: 'var(--serif)', fontSize: 64, lineHeight: 1, fontWeight: 400,
              color: 'var(--plum)', margin: 0, letterSpacing: -0.6, maxWidth: 700, textWrap: 'balance'
            }}>
              Three steps, ninety seconds, <span style={{ fontStyle: 'italic', color: 'var(--rose)' }}>peace of mind</span> for as long as you'd like it.
            </h2>
          </div>
          <Floret size={48} color="var(--blush-deep)" center="var(--ivory)" />
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 24 }}>
          {steps.map((s, i) =>
          <div key={i} style={{
            padding: '40px 32px 36px', borderRadius: 'var(--r-xl)',
            background: 'var(--pearl)', boxShadow: 'var(--shadow-sm)',
            position: 'relative', overflow: 'hidden'
          }}>
              <div style={{
              position: 'absolute', top: -40, right: -40, width: 160, height: 160, borderRadius: '50%',
              background: `radial-gradient(circle, ${s.accent} 0%, transparent 70%)`
            }} />
              <div style={{ position: 'relative', zIndex: 1 }}>
                <div style={{
                fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 64, color: 'var(--rose)',
                fontWeight: 300, lineHeight: 1, marginBottom: 16, opacity: 0.55
              }}>{s.num}</div>
                <h3 style={{
                fontFamily: 'var(--serif)', fontSize: 28, fontWeight: 400, color: 'var(--plum)',
                margin: 0, lineHeight: 1.1, letterSpacing: -0.3
              }}>{s.title}</h3>
                <p style={{
                fontFamily: 'var(--sans)', fontSize: 14.5, color: 'var(--plum-soft)', lineHeight: 1.6,
                margin: '14px 0 0', fontWeight: 300
              }}>{s.body}</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>);

}

// ── What you'll know ─────────────────────────────────────────────────────
function WhatYouKnow() {
  const sections = [
  { l: 'Phone intelligence', d: 'Carrier, line type, VoIP detection, geographic origin, age of number.' },
  { l: 'Identity signals', d: 'Full legal name, age, date of birth — cross-referenced across three sources.' },
  { l: 'Address history', d: 'Last five known addresses, ownership vs. rental, purchase and sale prices, trust holdings.' },
  { l: 'Marital & relationships', d: 'Current marital status, prior marriages, known relatives, close associates.' },
  { l: 'Professional profile', d: 'Employer, title, tenure, estimated income, estimated net worth, LLCs and business registrations.' },
  { l: 'Public record flags', d: 'Sex offender registry, bankruptcy, lawsuits and judgments, evictions, professional licenses, political donations.' },
  { l: 'Social footprint', d: 'Known social handles, presence assessment, inconsistencies across profiles, age discrepancies.' },
  { l: 'Our recommendation', d: 'A plain-English score, a short verdict, and the three to five things we\'d actually do next, in your shoes.' }];


  return (
    <section id="trust" style={{ padding: '40px 56px 120px', background: 'var(--ivory-warm)', position: 'relative', scrollMarginTop: 80 }}>
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '80px 0 0' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.6fr', gap: 80, alignItems: 'flex-start' }}>
          <div style={{ position: 'sticky', top: 100 }}>
            <span className="v-eyebrow" style={{ marginBottom: 14, display: 'block' }}>Inside every report</span>
            <h2 style={{
              fontFamily: 'var(--serif)', fontSize: 56, lineHeight: 1, fontWeight: 400,
              color: 'var(--plum)', margin: 0, letterSpacing: -0.5, textWrap: 'balance'
            }}>
              Eight chapters, <span style={{ fontStyle: 'italic', color: 'var(--rose)' }}>one quiet truth.</span>
            </h2>
            <p style={{
              fontFamily: 'var(--sans)', fontSize: 16, color: 'var(--plum-soft)', lineHeight: 1.6,
              margin: '24px 0 0', maxWidth: 380, fontWeight: 300
            }}>
              We cross-reference seven independent sources — Whitepages Pro, ATTOM, BeenVerified, Proxycurl, PACER, FEC, NSOPW — and write you the report your brilliant older sister would, if she had access to a PI.
            </p>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
            {sections.map((s, i) =>
            <div key={i} style={{
              display: 'flex', alignItems: 'flex-start', gap: 28,
              padding: '24px 0',
              borderTop: '1px solid var(--ivory-deep)'
            }}>
                <div style={{
                fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 22, color: 'var(--rose)',
                fontWeight: 300, width: 32, paddingTop: 4, opacity: 0.7
              }}>0{i + 1}</div>
                <div style={{ flex: 1 }}>
                  <h3 style={{
                  fontFamily: 'var(--serif)', fontSize: 26, fontWeight: 400, color: 'var(--plum)',
                  margin: 0, lineHeight: 1.15, letterSpacing: -0.2
                }}>{s.l}</h3>
                  <p style={{
                  fontFamily: 'var(--sans)', fontSize: 14.5, color: 'var(--plum-soft)', lineHeight: 1.6,
                  margin: '8px 0 0', fontWeight: 300, maxWidth: 580
                }}>{s.d}</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>);

}

// ── Testimonial ──────────────────────────────────────────────────────────
function Testimonial() {
  return (
    <section id="stories" style={{ padding: '120px 56px', position: 'relative', overflow: 'hidden', scrollMarginTop: 80 }}>
      <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', width: 600, height: 600,
        background: 'radial-gradient(circle, var(--blush-pale) 0%, transparent 65%)', opacity: 0.55 }} />
      <div style={{ maxWidth: 900, margin: '0 auto', textAlign: 'center', position: 'relative', zIndex: 1 }}>
        <Floret size={32} color="var(--rose)" center="var(--ivory)" style={{ margin: '0 auto 24px' }} />
        <blockquote style={{
          fontFamily: 'var(--serif)', fontSize: 44, lineHeight: 1.15, fontWeight: 400, color: 'var(--plum)',
          margin: 0, letterSpacing: -0.3, fontStyle: 'italic', textWrap: 'balance'
        }}>
          "He looked great on paper. Verity told me he'd been evicted twice and had filed for bankruptcy in 2019. I didn't go. I went out with my sister instead. <span style={{ fontStyle: 'normal', color: 'var(--rose)' }}>Best decision I've made all year.</span>"
        </blockquote>
        <div style={{ marginTop: 28, fontFamily: 'var(--sans)', fontSize: 13, color: 'var(--plum-soft)', letterSpacing: 0.4 }}>ELENA M. · 24· NEW YORK

        </div>
      </div>
    </section>);

}

// ── Final CTA ────────────────────────────────────────────────────────────
function FinalCTA({ onSearch }) {
  return (
    <section style={{ padding: '20px 56px 80px' }}>
      <div style={{
        maxWidth: 1280, margin: '0 auto', padding: '80px 64px',
        borderRadius: 'var(--r-xl)',
        background: 'linear-gradient(160deg, var(--primary) 0%, var(--primary-deep) 100%)',
        color: 'var(--ivory)', position: 'relative', overflow: 'hidden',
        textAlign: 'center'
      }}>
        <div style={{
          position: 'absolute', top: -100, right: -100, width: 400, height: 400, borderRadius: '50%',
          background: 'radial-gradient(circle, var(--champagne) 0%, transparent 60%)', opacity: 0.35
        }} />
        <div style={{
          position: 'absolute', bottom: -120, left: -120, width: 360, height: 360, borderRadius: '50%',
          background: 'radial-gradient(circle, var(--blush-pale) 0%, transparent 60%)', opacity: 0.45
        }} />

        <div style={{ position: 'relative', zIndex: 1 }}>
          <span className="v-eyebrow" style={{ color: 'var(--champagne)' }}>Begin</span>
          <h2 style={{
            fontFamily: 'var(--serif)', fontSize: 76, lineHeight: 1, fontWeight: 400,
            margin: '20px auto 0', color: 'var(--ivory)', maxWidth: 800, letterSpacing: -0.7, textWrap: 'balance'
          }}>
            Date <span style={{ fontStyle: 'italic', color: 'var(--champagne)' }}>deliberately.</span><br />
            Always on your terms.
          </h2>
          <p style={{
            fontFamily: 'var(--sans)', fontSize: 17, opacity: 0.85, lineHeight: 1.6,
            margin: '24px auto 0', maxWidth: 540, fontWeight: 300
          }}>
            One verified account, unlimited reports for one year. The price of one nice dinner. Membership renews only if you choose.
          </p>
          <a href={VERIFY_URL} style={{
            marginTop: 40, padding: '20px 36px', borderRadius: 'var(--r-pill)',
            background: 'var(--ivory)', color: 'var(--primary-deep)', border: 'none', cursor: 'pointer',
            fontFamily: 'var(--serif)', fontSize: 19, fontWeight: 500, letterSpacing: 0.2,
            display: 'inline-flex', alignItems: 'center', gap: 10, textDecoration: 'none',
            boxShadow: '0 16px 40px rgba(180, 30, 97, 0.35)'
          }}>
            Begin <span style={{ fontStyle: 'italic', fontWeight: 300 }}>verification</span> →
          </a>
        </div>
      </div>
    </section>);

}

// ── Footer ───────────────────────────────────────────────────────────────
function VFooter() {
  return (
    <footer style={{ padding: '60px 56px 40px', background: 'var(--ivory-warm)' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr 1fr', gap: 48, marginBottom: 48 }}>
          <div>
            <Wordmark size={28} color="var(--plum)" />
            <p style={{ fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 16, color: 'var(--plum-soft)', margin: '20px 0 0', lineHeight: 1.5, maxWidth: 280 }}>
              Quietly built for the woman who's done taking unnecessary risks.
            </p>
          </div>
          {[
          ['Product', [['How it works', '#how-it-works'], ['What you\'ll know', '#trust'], ['Pricing', VERIFY_URL], ['For brands', CONTACT_EMAIL]]],
          ['Trust', [['ID verification', VERIFY_URL], ['Privacy promise', '#'], ['How we score', '#how-it-works'], ['Sources', '#trust']]],
          ['Help', [['Get in touch', CONTACT_EMAIL], ['Story library', '#stories'], ['Press', CONTACT_EMAIL]]],
          ['Legal', [['Privacy policy', '#'], ['Terms', '#'], ['FCRA notice', '#'], ['Do not sell', '#']]]].
          map(([title, items]) =>
          <div key={title}>
              <div className="v-eyebrow" style={{ marginBottom: 16 }}>{title}</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {items.map(([label, href]) =>
              <a key={label} href={href} style={{ fontFamily: 'var(--sans)', fontSize: 13.5, color: 'var(--plum-soft)', textDecoration: 'none' }}>{label}</a>
              )}
              </div>
            </div>
          )}
        </div>

        <div style={{
          padding: '24px 0', borderTop: '1px solid var(--ivory-deep)',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 16
        }}>
          <div style={{ fontFamily: 'var(--sans)', fontSize: 12, color: 'var(--mauve-deep)', letterSpacing: 0.3 }}>© 2026 Mintploy, Inc. · Made quietly in Los Angeles · For women only

          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 16px', background: 'var(--sage-pale)', borderRadius: 'var(--r-pill)' }}>
            <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--sage-deep)' }} />
            <span style={{ fontFamily: 'var(--sans)', fontSize: 11.5, color: 'var(--sage-deep)', fontWeight: 500, letterSpacing: 0.3 }}>
              ID-verified female access · powered by Stripe
            </span>
          </div>
        </div>
      </div>
    </footer>);

}

// ── Landing page wrapper ─────────────────────────────────────────────────
function DesktopLanding({ onSearch, onCompare }) {
  return (
    <div id="top" data-screen-label="Verity Desktop / Landing" style={{ background: 'var(--ivory)', minHeight: '100vh' }}>
      <VNav active="home" onSearch={onSearch} onCompare={onCompare} />
      <DesktopHero onSearch={onSearch} />
      <PressStrip />
      <HowItWorks />
      <WhatYouKnow />
      <Testimonial />
      <FinalCTA onSearch={onSearch} />
      <VFooter />
    </div>);

}

Object.assign(window, { DesktopLanding, VNav, VFooter });