// mobile-compare.jsx — Compare screen for mobile

const { useState: useStateC, useMemo: useMemoC, useRef: useRefC } = React;

function ScreenCompare({ go }) {
  const [year, setYear] = useStateC(5);
  const men = window.COMPARE_MEN;
  const { fmtMoney, fmtMoneyShort, logY, rankProfiles } = window.compareUtils;

  const ranked = useMemoC(() => rankProfiles(men, year), [year]);
  const [expanded, setExpanded] = useStateC(null);

  return (
    <div style={{ position: 'relative', height: '100%', overflow: 'auto', paddingBottom: 80, background: 'var(--ivory)' }}>
      {/* Top bar — sticky */}
      <div style={{
        position: 'sticky', top: 0, zIndex: 30,
        padding: '52px 16px 12px',
        background: 'linear-gradient(180deg, var(--ivory) 60%, rgba(250,246,240,0))',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <button onClick={() => go('search')} style={{
            display: 'flex', alignItems: 'center', gap: 6, background: 'var(--pearl)',
            padding: '7px 13px', borderRadius: 'var(--r-pill)', border: 0, cursor: 'pointer',
            boxShadow: 'var(--shadow-xs)', color: 'var(--plum)', fontSize: 13, whiteSpace: 'nowrap',
          }}>
            <span style={{ fontSize: 16, lineHeight: 1 }}>←</span>
            <span style={{ fontFamily: 'var(--sans)' }}>Back</span>
          </button>
          <span style={{
            padding: '6px 13px', background: 'var(--blush)', borderRadius: 'var(--r-pill)',
            fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 13, color: 'var(--wine)', whiteSpace: 'nowrap',
          }}>
            Compare · {ranked.length} men
          </span>
        </div>
      </div>

      {/* Header */}
      <div style={{ padding: '0 22px', position: 'relative' }}>
        <div style={{ position: 'absolute', top: -20, right: -40, width: 200, height: 200,
          background: 'radial-gradient(circle, var(--blush-pale) 0%, transparent 70%)', opacity: 0.7 }}/>
        <div className="v-eyebrow" style={{ marginBottom: 10, position: 'relative' }}>Your shortlist · the honest math</div>
        <h1 style={{
          fontFamily: 'var(--serif)', fontSize: 40, lineHeight: 1.0, fontWeight: 400,
          color: 'var(--plum)', margin: 0, letterSpacing: -0.3, position: 'relative',
        }}>
          Where each of them<br/>
          <span style={{ fontStyle: 'italic', color: 'var(--rose)', fontWeight: 300 }}>actually</span> lands.
        </h1>
        <p style={{
          fontFamily: 'var(--sans)', fontSize: 13.5, lineHeight: 1.55, color: 'var(--plum-soft)',
          margin: '14px 0 0', fontWeight: 300, position: 'relative', maxWidth: 320,
        }}>
          Each man modeled on his archetype, risk-adjusted, with an honest confidence band. Slide the year. Watch them re-rank.
        </p>
      </div>

      {/* Year slider — premium feel */}
      <YearSlider year={year} setYear={setYear} />

      {/* Ranked cards */}
      <div style={{ padding: '0 16px', marginTop: 24, display: 'flex', flexDirection: 'column', gap: 12 }}>
        {ranked.map((m, i) => (
          <CompareCard
            key={m.id}
            man={m}
            rank={i + 1}
            year={year}
            expanded={expanded === m.id}
            onToggle={() => setExpanded(expanded === m.id ? null : m.id)}
          />
        ))}
      </div>

      {/* Trajectory chart */}
      <div style={{ padding: '32px 16px 0' }}>
        <TrajectoryChart men={men} year={year} setYear={setYear} />
      </div>

      {/* Verity's note */}
      <div style={{ padding: '24px 22px 0' }}>
        <DotDivider width={140} color="var(--mauve)" style={{ display: 'block', margin: '0 auto' }}/>
        <div style={{
          marginTop: 18, textAlign: 'center',
          fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 15, color: 'var(--plum-soft)',
          lineHeight: 1.5, textWrap: 'balance',
        }}>
          Income is one signal. The right partner isn't always the highest projection. But you deserve to make the call with both eyes open.
        </div>
        <div style={{
          marginTop: 14, textAlign: 'center',
          fontFamily: 'var(--sans)', fontSize: 10.5, color: 'var(--mauve-deep)', letterSpacing: 0.3, lineHeight: 1.6,
        }}>
          Modeled from BLS occupational data, archetype priors, and the public-record file we built on him. Projections are expected values · 80% confidence shown.
        </div>
      </div>
    </div>
  );
}

// ── Year Slider ─────────────────────────────────────────────────────────
function YearSlider({ year, setYear }) {
  const trackRef = useRefC(null);
  const [dragging, setDragging] = useStateC(false);

  const stops = [1, 5, 10, 20, 30, 50];

  const handleMove = (clientX) => {
    if (!trackRef.current) return;
    const rect = trackRef.current.getBoundingClientRect();
    const pct = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
    // log-ish mapping: more granular near 0
    const y = Math.round(1 + pct * 49);
    setYear(y);
  };

  const pct = (year - 1) / 49;

  return (
    <div style={{ padding: '20px 22px 0' }}>
      <div style={{
        display: 'flex', alignItems: 'baseline', gap: 12, marginBottom: 18,
      }}>
        <div style={{ fontFamily: 'var(--serif)', fontSize: 64, fontWeight: 400, color: 'var(--plum)', lineHeight: 1, letterSpacing: -1.5, fontVariantNumeric: 'tabular-nums' }}>
          {year}
        </div>
        <div style={{ fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 22, color: 'var(--rose)', lineHeight: 1 }}>
          {year === 1 ? 'year' : 'years'} out
        </div>
        <div style={{ marginLeft: 'auto', textAlign: 'right' }}>
          <div className="v-eyebrow" style={{ fontSize: 9.5, marginBottom: 2 }}>he'll be</div>
          <div style={{ fontFamily: 'var(--serif)', fontSize: 14, color: 'var(--plum-soft)', fontStyle: 'italic' }}>
            ~{Math.round((year + 36))} on avg
          </div>
        </div>
      </div>

      {/* Track */}
      <div
        ref={trackRef}
        onPointerDown={(e) => {
          setDragging(true);
          e.currentTarget.setPointerCapture(e.pointerId);
          handleMove(e.clientX);
        }}
        onPointerMove={(e) => { if (dragging) handleMove(e.clientX); }}
        onPointerUp={(e) => { setDragging(false); e.currentTarget.releasePointerCapture(e.pointerId); }}
        style={{
          position: 'relative', height: 36, padding: '14px 0', cursor: 'pointer',
          touchAction: 'none',
        }}
      >
        {/* Track line */}
        <div style={{
          position: 'absolute', left: 0, right: 0, top: '50%', height: 4,
          transform: 'translateY(-50%)', borderRadius: 2,
          background: 'var(--ivory-deep)',
        }}/>
        {/* Filled portion */}
        <div style={{
          position: 'absolute', left: 0, top: '50%', height: 4,
          transform: 'translateY(-50%)', borderRadius: 2,
          width: `${pct * 100}%`,
          background: 'linear-gradient(90deg, var(--blush) 0%, var(--rose) 100%)',
        }}/>
        {/* Stop ticks */}
        {stops.map(s => {
          const sp = (s - 1) / 49;
          return (
            <div key={s} style={{
              position: 'absolute', left: `${sp * 100}%`, top: '50%',
              transform: 'translate(-50%, -50%)',
              width: 3, height: 10, borderRadius: 1,
              background: s <= year ? 'var(--rose)' : 'var(--mauve)',
              opacity: s === year ? 0 : 0.6,
            }}/>
          );
        })}
        {/* Thumb */}
        <div style={{
          position: 'absolute', left: `${pct * 100}%`, top: '50%',
          transform: 'translate(-50%, -50%)',
          width: 28, height: 28, borderRadius: '50%',
          background: 'var(--ivory)',
          boxShadow: '0 4px 14px rgba(217,137,124,0.4), inset 0 0 0 2px var(--rose)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <div style={{ width: 10, height: 10, borderRadius: '50%', background: 'var(--rose)' }}/>
        </div>
      </div>

      {/* Stop labels */}
      <div style={{ position: 'relative', height: 18, marginTop: 4 }}>
        {stops.map(s => {
          const sp = (s - 1) / 49;
          return (
            <button key={s} onClick={() => setYear(s)} style={{
              position: 'absolute', left: `${sp * 100}%`, transform: 'translateX(-50%)',
              border: 0, background: 'transparent', padding: '2px 4px', cursor: 'pointer',
              fontFamily: 'var(--sans)', fontSize: 11, color: s === year ? 'var(--rose)' : 'var(--mauve-deep)',
              fontWeight: s === year ? 600 : 400, letterSpacing: 0.3,
            }}>
              {s}y
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ── Single comparison card ──────────────────────────────────────────────
function CompareCard({ man, rank, year, expanded, onToggle }) {
  const { fmtMoney } = window.compareUtils;
  const proj = man.project(year);
  const todayProj = man.project(0);
  const multiplier = proj.expected / todayProj.expected;
  const confRange = Math.abs(proj.high - proj.low) / 2 / proj.expected * 100;

  // Sparkline data
  const points = useMemoC(() => {
    const yrs = Array.from({ length: 26 }, (_, i) => i * 2);
    const vals = yrs.map(y => Math.log10(Math.max(50000, man.project(y).expected)));
    const minV = Math.min(...vals), maxV = Math.max(...vals);
    const range = maxV - minV || 1;
    return yrs.map((y, i) => ({
      x: (y / 50) * 100,
      yv: 100 - ((vals[i] - minV) / range) * 100,
    }));
  }, [man]);

  const sparkPath = points.map((p, i) => `${i ? 'L' : 'M'}${p.x},${p.yv}`).join(' ');
  const cursorX = (year / 50) * 100;

  const rankBg = rank === 1 ? 'var(--blush)' : rank === 2 ? 'var(--champagne)' : rank === 3 ? 'var(--ivory-warm)' : 'var(--ivory-deep)';
  const rankColor = rank === 1 ? 'var(--wine)' : 'var(--plum)';

  // Pull commentary from notes — closest milestone
  const milestoneKeys = [5, 10, 20];
  const closestKey = milestoneKeys.reduce((acc, k) => Math.abs(k - year) < Math.abs(acc - year) ? k : acc, 5);
  const commentary = man.notes[closestKey];

  return (
    <div style={{
      borderRadius: 'var(--r-lg)', background: 'var(--pearl)', boxShadow: 'var(--shadow-sm)',
      overflow: 'hidden',
    }}>
      <div style={{ padding: '16px 16px 14px', display: 'flex', alignItems: 'flex-start', gap: 14 }}>
        {/* Rank badge */}
        <div style={{
          width: 40, height: 40, borderRadius: '50%', background: rankBg, color: rankColor,
          display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
          fontFamily: 'var(--serif)', fontSize: 22, fontStyle: 'italic', fontWeight: 400,
          boxShadow: rank === 1 ? '0 0 0 3px var(--blush-pale)' : 'none',
        }}>{rank}</div>

        {/* Avatar */}
        <div style={{
          width: 44, height: 44, borderRadius: '50%',
          background: `linear-gradient(135deg, ${man.colorPale}, ${man.color})`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: 'var(--serif)', fontSize: 17, fontStyle: 'italic', color: 'var(--plum)',
          flexShrink: 0, boxShadow: 'inset 0 0 0 1px var(--ivory-deep)',
        }}>{man.initials}</div>

        {/* Name + role + projection */}
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: 10 }}>
            <div style={{ flex: '1 1 auto', minWidth: 0, fontFamily: 'var(--serif)', fontSize: 18, color: 'var(--plum)', lineHeight: 1.1, fontWeight: 400, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
              {man.name}
            </div>
            <div style={{ flexShrink: 0, fontFamily: 'var(--serif)', fontSize: 22, fontWeight: 400, color: 'var(--plum)', lineHeight: 1, letterSpacing: -0.3, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>
              {fmtMoney(proj.expected)}
            </div>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginTop: 6, gap: 10 }}>
            <div style={{ flex: '1 1 auto', minWidth: 0, fontFamily: 'var(--sans)', fontSize: 11.5, color: 'var(--plum-soft)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
              {man.role} · <span style={{ fontStyle: 'italic', fontFamily: 'var(--serif)', fontSize: 13 }}>{man.archetype}</span>
            </div>
            <div className="v-eyebrow" style={{ flexShrink: 0, fontSize: 9.5, color: man.colorDeep }}>
              ±{Math.round(confRange)}%
            </div>
          </div>
        </div>
      </div>

      {/* Sparkline trajectory */}
      <div style={{ padding: '0 16px 14px' }}>
        <svg viewBox="0 0 100 32" width="100%" height="32" preserveAspectRatio="none" style={{ display: 'block' }}>
          {/* Reference grid line at today */}
          <line x1="0" y1="50%" x2="100" y2="50%" stroke="var(--ivory-deep)" strokeWidth="0.3" strokeDasharray="1 1" vectorEffect="non-scaling-stroke"/>
          {/* Trajectory */}
          <path d={sparkPath} fill="none" stroke={man.color} strokeWidth="1.5" vectorEffect="non-scaling-stroke" strokeLinecap="round" strokeLinejoin="round"/>
          {/* Cursor for current year */}
          <line x1={cursorX} y1="0" x2={cursorX} y2="32" stroke="var(--rose)" strokeWidth="1" strokeDasharray="2 2" vectorEffect="non-scaling-stroke" opacity="0.6"/>
          <circle cx={cursorX} cy={(points.find(p => p.x >= cursorX) || points[points.length - 1]).yv} r="2.5" fill={man.color} stroke="var(--ivory)" strokeWidth="1" vectorEffect="non-scaling-stroke"/>
        </svg>
      </div>

      {/* Expandable section */}
      <div style={{ borderTop: '1px solid var(--ivory-deep)' }}>
        <button onClick={onToggle} style={{
          width: '100%', padding: '12px 16px', background: 'transparent', border: 0, cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          fontFamily: 'var(--sans)', fontSize: 12, color: 'var(--plum-soft)', letterSpacing: 0.3,
        }}>
          <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span className="v-eyebrow" style={{ fontSize: 10 }}>Verity's read</span>
          </span>
          <span style={{ fontSize: 14, transform: expanded ? 'rotate(180deg)' : 'rotate(0)', transition: 'transform .2s', color: 'var(--mauve-deep)' }}>⌄</span>
        </button>
        {expanded && (
          <div style={{ padding: '0 16px 16px' }}>
            <div style={{
              padding: '14px 16px', background: 'var(--ivory)', borderRadius: 'var(--r-md)',
              fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 14.5, color: 'var(--plum)',
              lineHeight: 1.55,
            }}>
              "{commentary}"
            </div>
            <div style={{ marginTop: 10, padding: '12px 14px', background: 'var(--ivory-warm)', borderRadius: 'var(--r-md)' }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 }}>
                <Mini label="Today" value={fmtMoney(todayProj.expected)}/>
                <Mini label={`Year ${year}`} value={fmtMoney(proj.expected)} accent={man.colorDeep}/>
                <Mini label="Multiple" value={`${multiplier.toFixed(1)}×`}/>
              </div>
              <div style={{ marginTop: 12, fontFamily: 'var(--sans)', fontSize: 12, color: 'var(--plum-soft)', lineHeight: 1.55, fontWeight: 300 }}>
                {man.summary}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function Mini({ label, value, accent }) {
  return (
    <div>
      <div className="v-eyebrow" style={{ fontSize: 9.5, marginBottom: 2 }}>{label}</div>
      <div style={{ fontFamily: 'var(--serif)', fontSize: 16, color: accent || 'var(--plum)', lineHeight: 1, fontVariantNumeric: 'tabular-nums' }}>{value}</div>
    </div>
  );
}

// ── Trajectory chart ────────────────────────────────────────────────────
function TrajectoryChart({ men, year, setYear, height = 220 }) {
  const W = 100, H = 100;
  const points = useMemoC(() => men.map(m => ({
    man: m,
    pts: Array.from({ length: 51 }, (_, y) => {
      const p = m.project(y);
      const yPx = (1 - window.compareUtils.logY(p.expected)) * H;
      const yPxHigh = (1 - window.compareUtils.logY(p.high)) * H;
      const yPxLow = (1 - window.compareUtils.logY(p.low)) * H;
      return { y, x: (y / 50) * W, yPx, yPxHigh, yPxLow };
    }),
  })), [men]);

  const path = (pts) => pts.map((p, i) => `${i ? 'L' : 'M'}${p.x.toFixed(2)},${p.yPx.toFixed(2)}`).join(' ');
  const band = (pts) => `M${pts.map(p => `${p.x.toFixed(2)},${p.yPxHigh.toFixed(2)}`).join(' L')} L${[...pts].reverse().map(p => `${p.x.toFixed(2)},${p.yPxLow.toFixed(2)}`).join(' L')} Z`;

  const cursorX = (year / 50) * W;

  // Y axis tick values (in dollars)
  const yTicks = [100000, 500000, 1000000, 5000000, 25000000];

  // Pan to set year on tap
  const svgRef = useRefC(null);
  const onPointer = (e) => {
    const rect = svgRef.current.getBoundingClientRect();
    const pct = (e.clientX - rect.left) / rect.width;
    const y = Math.max(0, Math.min(50, Math.round(pct * 50)));
    setYear(Math.max(1, y));
  };

  return (
    <div style={{
      padding: '20px 18px 16px', borderRadius: 'var(--r-lg)',
      background: 'var(--pearl)', boxShadow: 'var(--shadow-sm)',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
        <div>
          <div className="v-eyebrow" style={{ fontSize: 10, marginBottom: 4 }}>Trajectories</div>
          <div style={{ fontFamily: 'var(--serif)', fontSize: 20, color: 'var(--plum)', lineHeight: 1, fontWeight: 400 }}>
            <span style={{ fontStyle: 'italic', color: 'var(--rose)' }}>50 years</span>, side by side
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', justifyContent: 'flex-end' }}>
          {men.map(m => (
            <span key={m.id} style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
              <span style={{ width: 8, height: 8, borderRadius: '50%', background: m.color }}/>
              <span style={{ fontFamily: 'var(--sans)', fontSize: 10.5, color: 'var(--plum)', letterSpacing: 0.2 }}>{m.initials}</span>
            </span>
          ))}
        </div>
      </div>

      <div style={{ position: 'relative', height }}>
        {/* Y axis labels */}
        <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 40 }}>
          {yTicks.map(v => {
            const yp = (1 - window.compareUtils.logY(v)) * height;
            return (
              <div key={v} style={{
                position: 'absolute', top: yp, left: 0, transform: 'translateY(-50%)',
                fontFamily: 'var(--sans)', fontSize: 9.5, color: 'var(--mauve-deep)', letterSpacing: 0.3,
                fontVariantNumeric: 'tabular-nums',
              }}>
                {window.compareUtils.fmtMoney(v)}
              </div>
            );
          })}
        </div>

        <svg
          ref={svgRef}
          viewBox={`0 0 ${W} ${H}`}
          width="100%" height={height}
          preserveAspectRatio="none"
          style={{ display: 'block', marginLeft: 40, width: 'calc(100% - 40px)', cursor: 'col-resize', touchAction: 'none' }}
          onPointerDown={(e) => { e.currentTarget.setPointerCapture(e.pointerId); onPointer(e); }}
          onPointerMove={(e) => { if (e.buttons || e.pointerType === 'touch') onPointer(e); }}
        >
          {/* Y gridlines */}
          {yTicks.map(v => {
            const yp = (1 - window.compareUtils.logY(v)) * H;
            return <line key={v} x1="0" y1={yp} x2={W} y2={yp} stroke="var(--ivory-deep)" strokeWidth="0.2" vectorEffect="non-scaling-stroke"/>;
          })}
          {/* X gridlines at 5/10/20/30/50 years */}
          {[5, 10, 20, 30, 50].map(y => {
            const xp = (y / 50) * W;
            return <line key={y} x1={xp} y1="0" x2={xp} y2={H} stroke="var(--ivory-deep)" strokeWidth="0.2" vectorEffect="non-scaling-stroke" strokeDasharray="1 1.5"/>;
          })}

          {/* Confidence bands */}
          {points.map(({ man, pts }) => (
            <path key={man.id + '-band'} d={band(pts)} fill={man.color} opacity="0.08"/>
          ))}
          {/* Trajectory lines */}
          {points.map(({ man, pts }) => (
            <path key={man.id} d={path(pts)} fill="none" stroke={man.color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke"/>
          ))}

          {/* Cursor */}
          <line x1={cursorX} y1="0" x2={cursorX} y2={H} stroke="var(--plum)" strokeWidth="1" strokeDasharray="2 2" vectorEffect="non-scaling-stroke"/>
          {points.map(({ man, pts }) => {
            const p = pts[year] || pts[pts.length - 1];
            return <circle key={man.id + '-cur'} cx={cursorX} cy={p.yPx} r="2" fill={man.color} stroke="var(--ivory)" strokeWidth="1" vectorEffect="non-scaling-stroke"/>;
          })}
        </svg>

        {/* X axis labels */}
        <div style={{ position: 'absolute', left: 40, right: 0, bottom: -20, height: 16 }}>
          {[0, 5, 10, 20, 30, 50].map(y => {
            const xp = (y / 50) * 100;
            return (
              <div key={y} style={{
                position: 'absolute', left: `${xp}%`, transform: 'translateX(-50%)',
                fontFamily: 'var(--sans)', fontSize: 9.5, color: y === year ? 'var(--rose)' : 'var(--mauve-deep)', letterSpacing: 0.3, fontWeight: y === year ? 600 : 400,
              }}>
                {y === 0 ? 'now' : `${y}y`}
              </div>
            );
          })}
        </div>
      </div>

      <div style={{ marginTop: 28, fontFamily: 'var(--sans)', fontSize: 11.5, color: 'var(--mauve-deep)', lineHeight: 1.5, fontStyle: 'italic' }}>
        Faded bands show 80% confidence range · drag to change the year
      </div>
    </div>
  );
}

window.ScreenCompare = ScreenCompare;
