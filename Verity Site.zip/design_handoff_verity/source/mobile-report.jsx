// mobile-report.jsx — the Verity report screen
// Stacked soft-edge cards, score pinned at top, gentle reveal animations.

const { useMemo, useState: useStateR, useEffect: useEffectR } = React;

// ── Score Badge ─────────────────────────────────────────────────────────
function ScoreBadge({ score, persona }) {
  const config = {
    green: {
      label: 'Green light',
      sub: 'Proceed with ease.',
      bg: 'var(--sage-pale)', deep: 'var(--sage-deep)', accent: 'var(--sage)',
      glow: 'rgba(155, 176, 152, 0.35)',
    },
    yellow: {
      label: 'Soft yellow',
      sub: 'Worth a slower pace.',
      bg: 'var(--honey-pale)', deep: 'var(--honey-deep)', accent: 'var(--honey)',
      glow: 'rgba(217, 179, 112, 0.35)',
    },
    red: {
      label: 'Deep rose',
      sub: 'We\'d skip this one.',
      bg: 'var(--deeprose-pale)', deep: 'var(--deeprose-deep)', accent: 'var(--deeprose)',
      glow: 'rgba(201, 122, 133, 0.35)',
    },
  }[score];

  return (
    <div style={{
      margin: '8px 16px 0', borderRadius: 'var(--r-xl)',
      background: config.bg,
      padding: '24px 22px 22px',
      position: 'relative', overflow: 'hidden',
      boxShadow: `0 16px 40px ${config.glow}, 0 2px 6px rgba(61,36,52,0.06)`,
    }}>
      {/* Decorative bloom in corner */}
      <div style={{
        position: 'absolute', top: -40, right: -40, width: 160, height: 160, borderRadius: '50%',
        background: `radial-gradient(circle, ${config.accent} 0%, transparent 65%)`,
        opacity: 0.55,
      }} />

      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14, position: 'relative', zIndex: 1 }}>
        {/* Pulsing dot */}
        <div style={{
          width: 14, height: 14, borderRadius: '50%', background: config.deep,
          marginTop: 8, flexShrink: 0,
          boxShadow: `0 0 0 4px ${config.bg}, 0 0 0 5px ${config.accent}`,
          animation: 'vDotPulse 2.4s ease-in-out infinite',
        }}/>
        <style>{`@keyframes vDotPulse { 0%, 100% { box-shadow: 0 0 0 4px ${config.bg}, 0 0 0 5px ${config.accent} } 50% { box-shadow: 0 0 0 4px ${config.bg}, 0 0 0 9px ${config.accent}88 } }`}</style>
        <div style={{ flex: 1 }}>
          <div className="v-eyebrow" style={{ color: config.deep, fontSize: 10, marginBottom: 4 }}>Safety score · live</div>
          <div style={{
            fontFamily: 'var(--serif)', fontSize: 36, fontWeight: 400,
            color: config.deep, lineHeight: 1.0, letterSpacing: -0.2,
          }}>
            {config.label.split(' ')[0]}{' '}
            <span style={{ fontStyle: 'italic', fontWeight: 300 }}>{config.label.split(' ')[1]}</span>
          </div>
          <div style={{ fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 17, color: config.deep, opacity: 0.8, marginTop: 4 }}>
            {config.sub}
          </div>
        </div>
      </div>

      {/* Headline & summary */}
      <div style={{ position: 'relative', zIndex: 1, marginTop: 18, paddingTop: 16, borderTop: `1px solid ${config.deep}22` }}>
        <div style={{ fontFamily: 'var(--serif)', fontSize: 21, color: config.deep, lineHeight: 1.15, fontStyle: 'italic', fontWeight: 400 }}>
          "{persona.headline}"
        </div>
        <p style={{ fontFamily: 'var(--sans)', fontSize: 13, lineHeight: 1.6, color: 'var(--plum)', marginTop: 10, fontWeight: 300 }}>
          {persona.summary}
        </p>
      </div>

      {/* Tiny meta */}
      <div style={{ display: 'flex', gap: 16, marginTop: 16, fontFamily: 'var(--sans)', fontSize: 10.5, color: 'var(--plum-soft)', letterSpacing: 0.2 }}>
        <span><span style={{ opacity: 0.6 }}>Confidence</span> · 94%</span>
        <span><span style={{ opacity: 0.6 }}>Sources</span> · 7</span>
        <span><span style={{ opacity: 0.6 }}>Generated</span> · just now</span>
      </div>
    </div>
  );
}

// ── Subject Identity Card ───────────────────────────────────────────────
function SubjectCard({ persona, score }) {
  const initials = persona.name.split(' ').map(n => n[0]).join('');
  return (
    <div style={{
      margin: '14px 16px 0', borderRadius: 'var(--r-lg)',
      background: 'var(--pearl)', padding: '18px 20px',
      boxShadow: 'var(--shadow-sm)',
      display: 'flex', alignItems: 'center', gap: 16,
      position: 'relative', overflow: 'hidden',
    }}>
      {/* Portrait placeholder */}
      <div style={{
        width: 64, height: 64, borderRadius: '50%',
        background: `linear-gradient(135deg, var(--ivory-warm), var(--champagne))`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: 'var(--serif)', fontSize: 24, color: 'var(--plum-soft)',
        fontStyle: 'italic', fontWeight: 400, flexShrink: 0,
        boxShadow: 'inset 0 0 0 1px var(--ivory-deep)',
        position: 'relative',
      }}>
        {initials}
        <div style={{
          position: 'absolute', bottom: -2, right: -2, width: 18, height: 18, borderRadius: '50%',
          background: score === 'green' ? 'var(--sage)' : score === 'yellow' ? 'var(--honey)' : 'var(--deeprose)',
          border: '3px solid var(--pearl)',
        }}/>
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div className="v-eyebrow" style={{ fontSize: 10, marginBottom: 4 }}>Subject</div>
        <div style={{ fontFamily: 'var(--serif)', fontSize: 22, color: 'var(--plum)', lineHeight: 1.1, fontWeight: 400 }}>
          {persona.name}
        </div>
        <div style={{ fontFamily: 'var(--sans)', fontSize: 12, color: 'var(--plum-soft)', marginTop: 4 }}>
          Age {persona.age} · {persona.phoneInput}
        </div>
      </div>
    </div>
  );
}

// ── Section Card wrapper ────────────────────────────────────────────────
function SectionCard({ eyebrow, title, icon, children, accent = 'var(--blush-pale)', noPad }) {
  return (
    <div style={{
      margin: '14px 16px 0', borderRadius: 'var(--r-lg)',
      background: 'var(--pearl)', boxShadow: 'var(--shadow-sm)',
      overflow: 'hidden',
    }}>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 12,
        padding: '20px 20px 14px',
      }}>
        <div style={{
          width: 38, height: 38, borderRadius: '50%',
          background: accent, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
        }}>{icon}</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="v-eyebrow" style={{ fontSize: 10, marginBottom: 2 }}>{eyebrow}</div>
          <div style={{ fontFamily: 'var(--serif)', fontSize: 22, color: 'var(--plum)', lineHeight: 1.1, fontWeight: 400 }}>
            {title}
          </div>
        </div>
      </div>
      <div style={{ padding: noPad ? 0 : '0 20px 20px' }}>
        {children}
      </div>
    </div>
  );
}

// ── Icons (tiny SVGs for each section) ──────────────────────────────────
const sectionIcons = {
  phone: <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M4 1.5h10c.6 0 1 .5 1 1v13c0 .6-.4 1-1 1H4c-.6 0-1-.4-1-1v-13c0-.5.4-1 1-1z" stroke="var(--plum)" strokeWidth="1.3"/><circle cx="9" cy="14" r="0.8" fill="var(--plum)"/></svg>,
  identity: <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><circle cx="9" cy="7" r="3" stroke="var(--plum)" strokeWidth="1.3"/><path d="M3 16c1-3 3-4 6-4s5 1 6 4" stroke="var(--plum)" strokeWidth="1.3" strokeLinecap="round"/></svg>,
  address: <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M3 8l6-5 6 5v7H3V8z" stroke="var(--plum)" strokeWidth="1.3" strokeLinejoin="round"/><path d="M7 15v-4h4v4" stroke="var(--plum)" strokeWidth="1.3"/></svg>,
  rel: <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M5 5a3 3 0 0 1 4 0l0 0a3 3 0 0 1 4 0c1 1 1 3 0 4l-4 4-4-4c-1-1-1-3 0-4z" stroke="var(--plum)" strokeWidth="1.3" strokeLinejoin="round"/></svg>,
  prof: <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><rect x="2" y="5" width="14" height="11" rx="1.5" stroke="var(--plum)" strokeWidth="1.3"/><path d="M6 5V3.5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1V5" stroke="var(--plum)" strokeWidth="1.3"/></svg>,
  public: <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M9 1L2 4v5c0 4 7 8 7 8s7-4 7-8V4L9 1z" stroke="var(--plum)" strokeWidth="1.3" strokeLinejoin="round"/></svg>,
  social: <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><circle cx="9" cy="9" r="7" stroke="var(--plum)" strokeWidth="1.3"/><path d="M2 9h14M9 2c2 2 3 5 3 7s-1 5-3 7c-2-2-3-5-3-7s1-5 3-7z" stroke="var(--plum)" strokeWidth="1.3"/></svg>,
  steps: <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M2 14h4v-4H2v4zM7 14h4V8H7v6zM12 14h4V4h-4v10z" stroke="var(--plum)" strokeWidth="1.3" strokeLinejoin="round"/></svg>,
};

// ── Report ──────────────────────────────────────────────────────────────
function ScreenReport({ go, state }) {
  const persona = window.PERSONAS[state.score || 'yellow'];

  return (
    <div style={{ position: 'relative', height: '100%', overflow: 'auto', paddingBottom: 60 }}>
      {/* Top bar with home + share */}
      <div style={{
        position: 'sticky', top: 0, zIndex: 30,
        padding: '52px 16px 12px',
        background: 'linear-gradient(180deg, var(--ivory) 60%, rgba(250,246,240,0))',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <button onClick={() => go('search')} style={{
            display: 'flex', alignItems: 'center', gap: 6, background: 'var(--pearl)',
            padding: '7px 13px', borderRadius: 'var(--r-pill)', border: 0, cursor: 'pointer',
            boxShadow: 'var(--shadow-xs)', color: 'var(--plum)', fontSize: 13, whiteSpace: 'nowrap',
          }}>
            <span style={{ fontSize: 16, lineHeight: 1 }}>←</span>
            <span style={{ fontFamily: 'var(--sans)' }}>New search</span>
          </button>
          <div style={{ display: 'flex', gap: 8 }}>
            <IconBtn>
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M8 1v10M4 7l4 4 4-4M2 13h12" stroke="var(--plum)" strokeWidth="1.4" strokeLinecap="round"/></svg>
            </IconBtn>
            <IconBtn>
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><circle cx="3.5" cy="8" r="1.5" stroke="var(--plum)" strokeWidth="1.3"/><circle cx="12.5" cy="4" r="1.5" stroke="var(--plum)" strokeWidth="1.3"/><circle cx="12.5" cy="12" r="1.5" stroke="var(--plum)" strokeWidth="1.3"/><path d="M5 7l6-2.5M5 9l6 2.5" stroke="var(--plum)" strokeWidth="1.3"/></svg>
            </IconBtn>
          </div>
        </div>
      </div>

      {/* Score badge */}
      <ScoreBadge score={persona.score} persona={persona} />

      {/* Subject card */}
      <SubjectCard persona={persona} score={persona.score} />

      {/* Phone Intelligence */}
      <SectionCard eyebrow="Section 01" title="Phone intelligence" icon={sectionIcons.phone}>
        <KVList rows={[
          ['Carrier', persona.carrier],
          ['Line type', persona.voip ? 'Mobile + VoIP secondary' : 'Mobile, single line'],
          ['Number age', persona.numberAge],
          ['Origin', persona.origin],
        ]}/>
        {persona.voip && (
          <FlagNote tone={persona.score === 'red' ? 'red' : 'yellow'}>
            {persona.voip}
          </FlagNote>
        )}
      </SectionCard>

      {/* Identity Signals */}
      <SectionCard eyebrow="Section 02" title="Identity signals" icon={sectionIcons.identity} accent="var(--ivory-warm)">
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
          <Stat label="Full name" value={persona.name}/>
          <Stat label="Age" value={persona.age}/>
          <Stat label="Date of birth" value={persona.dob}/>
          <Stat label="Verified by" value="3 sources"/>
        </div>
      </SectionCard>

      {/* Address History */}
      <SectionCard eyebrow="Section 03" title="Address history" icon={sectionIcons.address} accent="var(--blush-pale)">
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          {persona.addresses.map((a, i) => (
            <div key={i} style={{
              display: 'flex', alignItems: 'flex-start', gap: 14, padding: '14px 0',
              borderTop: i ? '1px solid var(--ivory-deep)' : 'none',
            }}>
              <div style={{ position: 'relative', paddingTop: 4 }}>
                <div style={{
                  width: 10, height: 10, borderRadius: '50%',
                  background: a.flag ? 'var(--deeprose)' : a.current ? 'var(--rose)' : 'var(--mauve)',
                  border: a.current ? '2px solid var(--blush-pale)' : 'none',
                  boxShadow: a.current ? '0 0 0 1px var(--rose)' : 'none',
                }}/>
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 2, flexWrap: 'wrap' }}>
                  <span style={{ fontFamily: 'var(--sans)', fontSize: 11, fontWeight: 500, color: 'var(--mauve-deep)', letterSpacing: 0.3 }}>{a.years}</span>
                  {a.current && <span style={{ fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 12, color: 'var(--rose)' }}>· current</span>}
                </div>
                <div style={{ fontFamily: 'var(--serif)', fontSize: 17, color: 'var(--plum)', lineHeight: 1.2, fontWeight: 400 }}>{a.addr}</div>
                <div style={{ fontFamily: 'var(--sans)', fontSize: 12, color: a.flag ? 'var(--deeprose-deep)' : 'var(--plum-soft)', marginTop: 4, lineHeight: 1.4, fontWeight: a.flag ? 500 : 300 }}>
                  {a.detail}
                </div>
              </div>
            </div>
          ))}
        </div>
      </SectionCard>

      {/* Relationships */}
      <SectionCard eyebrow="Section 04" title="Relationships & marital" icon={sectionIcons.rel} accent="var(--blush-pale)">
        <Stat label="Current status" value={persona.relationships.status} block/>
        {persona.relationships.spouse !== '—' && <Stat label="Spouse" value={persona.relationships.spouse} block/>}
        <Stat label="Prior marriages" value={persona.relationships.priors} block/>

        <SubLabel>Known relatives</SubLabel>
        <TagWrap items={persona.relationships.relatives}/>

        <SubLabel>Close associates</SubLabel>
        <TagWrap items={persona.relationships.associates}/>
      </SectionCard>

      {/* Professional */}
      <SectionCard eyebrow="Section 05" title="Professional profile" icon={sectionIcons.prof} accent="var(--ivory-warm)">
        <div style={{
          padding: '14px 16px', background: 'var(--ivory)', borderRadius: 'var(--r-md)', marginBottom: 14,
        }}>
          <div style={{ fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 18, color: 'var(--plum)', lineHeight: 1.2 }}>
            {persona.professional.title}
          </div>
          <div style={{ fontFamily: 'var(--sans)', fontSize: 12.5, color: 'var(--plum-soft)', marginTop: 4 }}>
            {persona.professional.company} · {persona.professional.tenure}
          </div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
          <Stat label="Est. income" value={persona.professional.income}/>
          <Stat label="Est. net worth" value={persona.professional.networth}/>
        </div>
        <SubLabel>Business entities</SubLabel>
        <div style={{ fontFamily: 'var(--sans)', fontSize: 13, color: 'var(--plum)', lineHeight: 1.5, fontWeight: 300 }}>
          {persona.professional.llcs}
        </div>
      </SectionCard>

      {/* Public Records */}
      <SectionCard eyebrow="Section 06" title="Public record flags" icon={sectionIcons.public} accent={persona.score === 'red' ? 'var(--deeprose-pale)' : 'var(--blush-pale)'}>
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          {persona.public.map((p, i) => (
            <div key={i} style={{
              display: 'flex', alignItems: 'flex-start', gap: 12, padding: '12px 0',
              borderTop: i ? '1px solid var(--ivory-deep)' : 'none',
            }}>
              <div style={{
                width: 22, height: 22, borderRadius: '50%', flexShrink: 0, marginTop: 1,
                background: p.good ? 'var(--sage-pale)' : p.flag ? 'var(--deeprose-pale)' : 'var(--ivory-warm)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                {p.good && <svg width="11" height="11" viewBox="0 0 11 11"><path d="M2 6l2.5 2.5L9 3" stroke="var(--sage-deep)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" fill="none"/></svg>}
                {p.flag && <svg width="11" height="11" viewBox="0 0 11 11"><path d="M5.5 2v3.5M5.5 8v0.5" stroke="var(--deeprose-deep)" strokeWidth="2" strokeLinecap="round"/></svg>}
                {p.neutral && <div style={{ width: 5, height: 5, borderRadius: '50%', background: 'var(--mauve-deep)' }}/>}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div className="v-eyebrow" style={{ fontSize: 9.5, marginBottom: 2 }}>{p.label}</div>
                <div style={{
                  fontFamily: 'var(--sans)', fontSize: 13, lineHeight: 1.4,
                  color: p.flag ? 'var(--deeprose-deep)' : 'var(--plum)',
                  fontWeight: p.flag ? 500 : 300,
                }}>{p.value}</div>
              </div>
            </div>
          ))}
        </div>
      </SectionCard>

      {/* Social */}
      <SectionCard eyebrow="Section 07" title="Social footprint" icon={sectionIcons.social} accent="var(--ivory-warm)">
        <SubLabel>Known handles</SubLabel>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          {persona.social.handles.map((h, i) => (
            <div key={i} style={{
              padding: '8px 12px', background: 'var(--ivory)', borderRadius: 'var(--r-md)',
              fontFamily: 'var(--sans)', fontSize: 12.5, color: 'var(--plum)',
            }}>{h}</div>
          ))}
        </div>
        <SubLabel>Presence assessment</SubLabel>
        <div style={{ fontFamily: 'var(--sans)', fontSize: 13, color: 'var(--plum)', lineHeight: 1.5, fontWeight: 300 }}>
          {persona.social.presence}
        </div>
        {persona.social.inconsistency !== 'None flagged.' && (
          <FlagNote tone={persona.score === 'red' ? 'red' : 'yellow'}>
            <strong style={{ fontWeight: 600 }}>Inconsistency: </strong>{persona.social.inconsistency}
          </FlagNote>
        )}
      </SectionCard>

      {/* Next Steps */}
      <div style={{
        margin: '14px 16px 0', borderRadius: 'var(--r-lg)',
        background: 'linear-gradient(160deg, var(--primary-deep) 0%, var(--plum) 100%)',
        padding: '22px 22px 24px', color: 'var(--ivory)',
        position: 'relative', overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute', top: -30, right: -30, width: 140, height: 140, borderRadius: '50%',
          background: 'radial-gradient(circle, var(--rose) 0%, transparent 65%)', opacity: 0.4,
        }}/>
        <div style={{ position: 'relative', zIndex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
            <Floret size={20} color="var(--blush)" center="var(--wine)"/>
            <div className="v-eyebrow" style={{ color: 'var(--blush)' }}>Section 08 · your move</div>
          </div>
          <h3 style={{
            fontFamily: 'var(--serif)', fontSize: 26, fontWeight: 400, lineHeight: 1.1,
            margin: 0, color: 'var(--ivory)',
          }}>
            What we'd <span style={{ fontStyle: 'italic', color: 'var(--blush)' }}>do next</span>,<br/>
            in your shoes.
          </h3>
          <div style={{ marginTop: 18, display: 'flex', flexDirection: 'column', gap: 12 }}>
            {persona.nextSteps.map((s, i) => (
              <div key={i} style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
                <div style={{
                  fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 18,
                  color: 'var(--blush)', lineHeight: 1, flexShrink: 0, paddingTop: 2,
                  width: 22, textAlign: 'right',
                }}>{String(i + 1).padStart(2, '0')}</div>
                <div style={{
                  fontFamily: 'var(--sans)', fontSize: 13.5, color: 'var(--ivory)',
                  lineHeight: 1.5, opacity: 0.92, fontWeight: 300,
                }}>{s}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Footer */}
      <div style={{ margin: '20px 16px 0', padding: '0 4px' }}>
        <div style={{ textAlign: 'center' }}>
          <DotDivider width={140} color="var(--mauve)"/>
        </div>
        <div style={{
          marginTop: 16, textAlign: 'center',
          fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 14, color: 'var(--plum-soft)',
          lineHeight: 1.5,
        }}>
          Verity does not predict the future.<br/>
          It tells you what's true today, so you can decide tomorrow.
        </div>
        <div style={{
          marginTop: 16, textAlign: 'center',
          fontFamily: 'var(--sans)', fontSize: 10.5, color: 'var(--mauve-deep)', letterSpacing: 0.3, lineHeight: 1.6,
        }}>
          Report ID · VR-2026-04-12-7A3E · sources: Whitepages Pro, ATTOM, BeenVerified, PACER, FEC, NSOPW, PDL<br/>
          <span style={{ textDecoration: 'underline' }}>Disclaimer</span> · <span style={{ textDecoration: 'underline' }}>Privacy</span> · <span style={{ textDecoration: 'underline' }}>How we score</span>
        </div>
      </div>
    </div>
  );
}

// ── Small helpers ───────────────────────────────────────────────────────
function IconBtn({ children }) {
  return (
    <button style={{
      width: 36, height: 36, borderRadius: '50%', border: 0,
      background: 'var(--pearl)', display: 'flex', alignItems: 'center', justifyContent: 'center',
      cursor: 'pointer', boxShadow: 'var(--shadow-xs)',
    }}>{children}</button>
  );
}

function KVList({ rows }) {
  return (
    <div>
      {rows.map(([k, v], i) => (
        <div key={i} style={{
          display: 'flex', alignItems: 'baseline', gap: 12, padding: '10px 0',
          borderTop: i ? '1px solid var(--ivory-deep)' : 'none',
        }}>
          <div className="v-eyebrow" style={{ fontSize: 10, flexShrink: 0, width: 90 }}>{k}</div>
          <div style={{ flex: 1, fontFamily: 'var(--sans)', fontSize: 13, color: 'var(--plum)', lineHeight: 1.4, fontWeight: 300 }}>{v}</div>
        </div>
      ))}
    </div>
  );
}

function Stat({ label, value, block }) {
  return (
    <div style={{ marginBottom: block ? 12 : 0 }}>
      <div className="v-eyebrow" style={{ fontSize: 10, marginBottom: 4 }}>{label}</div>
      <div style={{ fontFamily: 'var(--serif)', fontSize: 17, color: 'var(--plum)', lineHeight: 1.2, fontWeight: 400 }}>{value}</div>
    </div>
  );
}

function SubLabel({ children }) {
  return <div className="v-eyebrow" style={{ fontSize: 10, margin: '16px 0 8px' }}>{children}</div>;
}

function TagWrap({ items }) {
  return (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
      {items.map((it, i) => (
        <span key={i} style={{
          padding: '6px 12px', background: 'var(--ivory)', borderRadius: 'var(--r-pill)',
          fontFamily: 'var(--sans)', fontSize: 12, color: 'var(--plum)', lineHeight: 1.2, fontWeight: 400,
        }}>{it}</span>
      ))}
    </div>
  );
}

function FlagNote({ tone, children }) {
  const colors = {
    yellow: { bg: 'var(--honey-pale)', fg: 'var(--honey-deep)' },
    red: { bg: 'var(--deeprose-pale)', fg: 'var(--deeprose-deep)' },
  }[tone];
  return (
    <div style={{
      marginTop: 14, padding: '12px 14px', borderRadius: 'var(--r-md)',
      background: colors.bg, color: colors.fg,
      fontFamily: 'var(--sans)', fontSize: 12.5, lineHeight: 1.5, fontWeight: 400,
      display: 'flex', gap: 10, alignItems: 'flex-start',
    }}>
      <svg width="14" height="14" viewBox="0 0 14 14" style={{ flexShrink: 0, marginTop: 2 }}>
        <path d="M7 1L13 12H1L7 1z" stroke={colors.fg} strokeWidth="1.3" fill="none" strokeLinejoin="round"/>
        <path d="M7 6v3M7 10.5v0.5" stroke={colors.fg} strokeWidth="1.3" strokeLinecap="round"/>
      </svg>
      <div>{children}</div>
    </div>
  );
}

Object.assign(window, { ScreenReport, ScoreBadge, SubjectCard, SectionCard });
