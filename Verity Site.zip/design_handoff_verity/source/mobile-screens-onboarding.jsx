// mobile-screens-onboarding.jsx — Landing, Verify, Search, Loading screens
// All screens render inside the iOS frame's content area (above home indicator).

const { useState, useEffect, useRef } = React;

// ── Shared chrome ───────────────────────────────────────────────────────
// Generic top bar — tiny VERITY mark on left, plus optional action on right
function VTopBar({ left, right, mini = false }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '52px 22px 0',
      height: mini ? 80 : 92, boxSizing: 'border-box',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        {left ?? <Wordmark size={20} color="var(--plum)" />}
      </div>
      <div>{right}</div>
    </div>
  );
}

// Small step indicator dots — n of N
function StepDots({ step, total }) {
  return (
    <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
      {Array.from({ length: total }).map((_, i) => (
        <div key={i} style={{
          width: i === step ? 18 : 6, height: 6, borderRadius: 3,
          background: i <= step ? 'var(--wine)' : 'var(--ivory-deep)',
          transition: 'width .35s cubic-bezier(.5,1.5,.4,1)',
        }} />
      ))}
    </div>
  );
}

// Primary CTA — bubblegum pink pill, the new pop
function VPrimary({ children, onClick, disabled, fullWidth = true, variant = 'primary' }) {
  const bg = variant === 'primary' ? 'var(--primary)' : variant === 'blush' ? 'var(--blush)' : variant === 'dark' ? 'var(--plum)' : 'var(--primary-deep)';
  const fg = variant === 'blush' ? 'var(--plum)' : 'var(--ivory)';
  return (
    <button onClick={onClick} disabled={disabled}
      style={{
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 10,
        padding: '18px 28px', borderRadius: 'var(--r-pill)',
        background: bg, color: fg, border: 'none',
        fontFamily: 'var(--serif)', fontSize: 19, fontWeight: 500, letterSpacing: 0.2,
        whiteSpace: 'nowrap',
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.4 : 1,
        width: fullWidth ? '100%' : 'auto',
        boxShadow: variant === 'primary' ? 'var(--shadow-pop)' : '0 8px 24px rgba(44,14,38,0.18), 0 2px 6px rgba(44,14,38,0.08)',
        transition: 'transform .15s, box-shadow .15s',
      }}
      onMouseDown={(e) => e.currentTarget.style.transform = 'scale(0.98)'}
      onMouseUp={(e) => e.currentTarget.style.transform = 'scale(1)'}
      onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}>
      {children}
    </button>
  );
}

// Secondary text button
function VSecondary({ children, onClick }) {
  return (
    <button onClick={onClick} style={{
      background: 'transparent', border: 'none',
      fontFamily: 'var(--sans)', fontSize: 14, color: 'var(--mauve-deep)',
      cursor: 'pointer', padding: 10, letterSpacing: 0.4,
    }}>{children}</button>
  );
}

// ── Landing Screen ──────────────────────────────────────────────────────
function ScreenLanding({ go }) {
  return (
    <div style={{ position: 'relative', height: '100%', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      {/* Decorative petal blobs */}
      <div style={{ position: 'absolute', top: -40, right: -60, width: 220, height: 220,
        background: 'radial-gradient(circle, var(--blush) 0%, transparent 70%)', opacity: 0.55 }} />
      <div style={{ position: 'absolute', top: 180, left: -80, width: 200, height: 200,
        background: 'radial-gradient(circle, var(--champagne) 0%, transparent 70%)', opacity: 0.4 }} />
      <div style={{ position: 'absolute', bottom: 240, right: -50, width: 180, height: 180,
        background: 'radial-gradient(circle, var(--blush-pale) 0%, transparent 70%)', opacity: 0.7 }} />

      <VTopBar
        right={<VSecondary onClick={() => go('verifyIntro')}>Sign in</VSecondary>}
      />

      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', padding: '20px 28px 30px', position: 'relative', zIndex: 1 }}>
        {/* Editorial sticker */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 30, marginBottom: 28 }}>
          <span className="v-sticker">
            <Sparkle size={10} color="var(--wine)" /> for her, only
          </span>
        </div>

        {/* Hero headline */}
        <h1 style={{
          fontFamily: 'var(--serif)', fontSize: 56, lineHeight: 0.96, fontWeight: 400,
          color: 'var(--plum)', margin: 0, letterSpacing: -0.5,
          textWrap: 'balance',
        }}>
          Know him<br/>
          <span style={{ fontStyle: 'italic', color: 'var(--rose)', fontWeight: 300 }}>before</span>
          {' '}you<br/>
          meet him<span style={{ color: 'var(--rose)' }}>.</span>
        </h1>

        <p style={{
          fontFamily: 'var(--sans)', fontSize: 15.5, lineHeight: 1.55, color: 'var(--plum-soft)',
          margin: '24px 0 0', maxWidth: 290, fontWeight: 300,
        }}>
          Private intelligence on the man you're about to meet. Phone number in. Full picture out — quietly, in seconds.
        </p>

        <div style={{ flex: 1 }} />

        {/* Trust strip */}
        <div style={{
          display: 'flex', alignItems: 'center', gap: 14, padding: '14px 18px',
          background: 'rgba(255,253,249,0.7)', backdropFilter: 'blur(8px)',
          borderRadius: 'var(--r-pill)', marginBottom: 18,
          boxShadow: 'var(--shadow-sm)',
        }}>
          {/* Avatar cluster placeholder */}
          <div style={{ display: 'flex' }}>
            {['var(--blush-deep)','var(--champagne)','var(--mauve)'].map((c, i) => (
              <div key={i} style={{
                width: 26, height: 26, borderRadius: '50%', background: c,
                border: '2px solid var(--ivory)', marginLeft: i ? -8 : 0,
              }}/>
            ))}
          </div>
          <div style={{ fontFamily: 'var(--sans)', fontSize: 12.5, color: 'var(--plum-soft)', lineHeight: 1.3 }}>
            <span style={{ fontWeight: 600, color: 'var(--plum)' }}>47,232 women</span> have verified ·{' '}
            <span style={{ fontStyle: 'italic', fontFamily: 'var(--serif)', fontSize: 14 }}>her circle</span>
          </div>
        </div>

        <VPrimary onClick={() => go('verifyIntro')}>
          Begin <span style={{ fontStyle: 'italic', fontWeight: 300 }}>verification</span>
          <span style={{ marginLeft: 4 }}>→</span>
        </VPrimary>

        <div style={{
          textAlign: 'center', marginTop: 14,
          fontFamily: 'var(--sans)', fontSize: 11.5, color: 'var(--mauve-deep)',
          letterSpacing: 0.3,
        }}>
          Verified women only · ID required · Powered by Stripe
        </div>
      </div>
    </div>
  );
}

// ── Verify Intro Screen ─────────────────────────────────────────────────
function ScreenVerifyIntro({ go }) {
  const steps = [
    { label: 'A photo of your ID', sub: '15 seconds', icon: 'id' },
    { label: 'A short selfie', sub: '10 seconds', icon: 'face' },
    { label: 'Verity, unlocked', sub: 'forever', icon: 'bloom' },
  ];
  return (
    <div style={{ position: 'relative', height: '100%', display: 'flex', flexDirection: 'column' }}>
      <VTopBar
        left={<button onClick={() => go('landing')} style={{ background: 'transparent', border: 0, padding: 0, cursor: 'pointer', color: 'var(--plum-soft)', fontSize: 18 }}>←</button>}
      />
      <div style={{ flex: 1, padding: '12px 28px 30px', display: 'flex', flexDirection: 'column' }}>
        <div className="v-eyebrow" style={{ marginBottom: 14 }}>Onboarding · The ritual</div>
        <h2 style={{
          fontFamily: 'var(--serif)', fontSize: 38, lineHeight: 1.02, fontWeight: 400,
          color: 'var(--plum)', margin: 0, letterSpacing: -0.3,
        }}>
          <span style={{ fontStyle: 'italic', color: 'var(--rose)', fontWeight: 300 }}>Welcome,</span> we'll<br/>
          take it from here.
        </h2>
        <p style={{ fontFamily: 'var(--sans)', fontSize: 14.5, color: 'var(--plum-soft)', lineHeight: 1.55, marginTop: 16, fontWeight: 300 }}>
          Verity is exclusively for women. Verification happens once and takes under ninety seconds. After this you can search freely, always.
        </p>

        <div style={{ marginTop: 30, display: 'flex', flexDirection: 'column', gap: 16 }}>
          {steps.map((s, i) => (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 16,
              padding: '18px 20px', background: 'var(--pearl)',
              borderRadius: 'var(--r-lg)', boxShadow: 'var(--shadow-sm)',
            }}>
              <div style={{
                width: 42, height: 42, borderRadius: '50%',
                background: i === 0 ? 'var(--blush)' : i === 1 ? 'var(--champagne)' : 'var(--sage-pale)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                {s.icon === 'id' && <svg width="20" height="14" viewBox="0 0 20 14" fill="none"><rect x="0.5" y="0.5" width="19" height="13" rx="2" stroke="var(--plum)" strokeWidth="1.2"/><circle cx="5" cy="6" r="2" fill="var(--plum)" opacity="0.7"/><path d="M10 5h7M10 8h5" stroke="var(--plum)" strokeWidth="1.2" strokeLinecap="round" opacity="0.7"/></svg>}
                {s.icon === 'face' && <svg width="20" height="20" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="8" r="3" stroke="var(--plum)" strokeWidth="1.4"/><path d="M3 18c1.5-3.5 4-5 7-5s5.5 1.5 7 5" stroke="var(--plum)" strokeWidth="1.4" strokeLinecap="round"/></svg>}
                {s.icon === 'bloom' && <Floret size={22} color="var(--sage-deep)" center="var(--ivory)" />}
              </div>
              <div style={{ flex: 1 }}>
                <div className="v-eyebrow" style={{ fontSize: 10, marginBottom: 2 }}>0{i + 1}</div>
                <div style={{ fontFamily: 'var(--serif)', fontSize: 19, color: 'var(--plum)', lineHeight: 1.15 }}>{s.label}</div>
              </div>
              <div style={{ fontFamily: 'var(--sans)', fontSize: 12, color: 'var(--mauve-deep)', fontStyle: 'italic' }}>
                {s.sub}
              </div>
            </div>
          ))}
        </div>

        <div style={{ flex: 1 }} />

        <div style={{
          padding: '14px 18px', borderRadius: 'var(--r-md)',
          background: 'var(--ivory-warm)', marginBottom: 16,
          fontFamily: 'var(--sans)', fontSize: 12.5, lineHeight: 1.5, color: 'var(--plum-soft)',
        }}>
          <span style={{ fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 14, color: 'var(--plum)' }}>A note from us — </span>
          Your ID is processed by Stripe Identity and immediately deleted. Verity only stores that you verified, never how.
        </div>

        <VPrimary onClick={() => go('verifyId')}>Begin verification →</VPrimary>
      </div>
    </div>
  );
}

// ── Verify ID Screen ────────────────────────────────────────────────────
function ScreenVerifyId({ go }) {
  const [scanning, setScanning] = useState(false);
  const [done, setDone] = useState(false);

  useEffect(() => {
    if (scanning) {
      const t = setTimeout(() => { setScanning(false); setDone(true); }, 2200);
      return () => clearTimeout(t);
    }
  }, [scanning]);

  return (
    <div style={{ position: 'relative', height: '100%', display: 'flex', flexDirection: 'column' }}>
      <VTopBar
        left={<button onClick={() => go('verifyIntro')} style={{ background: 'transparent', border: 0, padding: 0, cursor: 'pointer', color: 'var(--plum-soft)', fontSize: 18 }}>←</button>}
        right={<StepDots step={0} total={3} />}
      />
      <div style={{ flex: 1, padding: '12px 28px 30px', display: 'flex', flexDirection: 'column' }}>
        <div className="v-eyebrow" style={{ marginBottom: 12 }}>Step one of three</div>
        <h2 style={{ fontFamily: 'var(--serif)', fontSize: 32, lineHeight: 1.05, fontWeight: 400, color: 'var(--plum)', margin: 0 }}>
          A photo of your <span style={{ fontStyle: 'italic', color: 'var(--rose)' }}>ID</span>.
        </h2>
        <p style={{ fontFamily: 'var(--sans)', fontSize: 14, color: 'var(--plum-soft)', lineHeight: 1.55, marginTop: 12, fontWeight: 300 }}>
          Place your driver's license, passport, or state ID inside the frame. We accept any government-issued photo ID.
        </p>

        <div style={{ marginTop: 28, position: 'relative' }}>
          {/* ID card frame */}
          <div style={{
            aspectRatio: '1.586 / 1', borderRadius: 'var(--r-lg)',
            background: 'var(--ivory-warm)',
            border: '1.5px dashed var(--mauve)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            position: 'relative', overflow: 'hidden',
          }}>
            {/* corner marks */}
            {[['top:14px;left:14px','M0 12V0H12','rotate(0)'],
              ['top:14px;right:14px','M0 12V0H12','rotate(90)'],
              ['bottom:14px;right:14px','M0 12V0H12','rotate(180)'],
              ['bottom:14px;left:14px','M0 12V0H12','rotate(270)']].map(([pos, d, rot], i) => {
                const style = Object.fromEntries(pos.split(';').map(p => { const [k, v] = p.split(':'); return [k, v.trim()]; }));
                return (
                  <svg key={i} width="22" height="22" viewBox="0 0 22 22" style={{ position: 'absolute', ...style }}>
                    <path d={d} stroke="var(--plum)" strokeWidth="2" fill="none" strokeLinecap="round" transform={rot + ' translate(0 0)'} style={{ transformOrigin: 'center' }}/>
                  </svg>
                );
              })}

            {!scanning && !done && (
              <div style={{ textAlign: 'center' }}>
                <div style={{
                  width: 56, height: 56, borderRadius: '50%', background: 'var(--blush)',
                  margin: '0 auto 12px', display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <svg width="24" height="20" viewBox="0 0 24 20" fill="none">
                    <rect x="1" y="3" width="22" height="16" rx="3" stroke="var(--plum)" strokeWidth="1.5"/>
                    <circle cx="12" cy="11" r="4" stroke="var(--plum)" strokeWidth="1.5"/>
                    <path d="M7 3l1.5-2h7L17 3" stroke="var(--plum)" strokeWidth="1.5" fill="none"/>
                  </svg>
                </div>
                <div style={{ fontFamily: 'var(--serif)', fontSize: 17, color: 'var(--plum)', fontStyle: 'italic' }}>
                  Position ID inside frame
                </div>
              </div>
            )}

            {scanning && (
              <div style={{ textAlign: 'center' }}>
                {/* Scanning line */}
                <div style={{
                  position: 'absolute', left: 24, right: 24, height: 2,
                  background: 'linear-gradient(90deg, transparent, var(--rose), transparent)',
                  animation: 'vScan 2s linear infinite',
                }}/>
                <div style={{ fontFamily: 'var(--serif)', fontSize: 17, color: 'var(--plum)', fontStyle: 'italic' }}>
                  Reading your ID…
                </div>
              </div>
            )}

            {done && (
              <div style={{ textAlign: 'center' }}>
                <div style={{
                  width: 56, height: 56, borderRadius: '50%', background: 'var(--sage)',
                  margin: '0 auto 12px', display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <svg width="22" height="22" viewBox="0 0 22 22" fill="none"><path d="M4 11l5 5 9-11" stroke="var(--ivory)" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"/></svg>
                </div>
                <div style={{ fontFamily: 'var(--serif)', fontSize: 17, color: 'var(--plum)', fontStyle: 'italic' }}>
                  ID accepted
                </div>
              </div>
            )}
          </div>

          <style>{`@keyframes vScan { 0% { top: 12%; } 50% { top: 75%; } 100% { top: 12%; } }`}</style>
        </div>

        <div style={{ marginTop: 18, padding: '12px 16px', background: 'var(--blush-pale)', borderRadius: 'var(--r-md)' }}>
          <div className="v-eyebrow" style={{ fontSize: 10, color: 'var(--wine)', marginBottom: 4 }}>For the cleanest read</div>
          <div style={{ fontFamily: 'var(--sans)', fontSize: 12.5, color: 'var(--plum-soft)', lineHeight: 1.5 }}>
            Even lighting. Flat surface. All four corners visible. No glare across your photo.
          </div>
        </div>

        <div style={{ flex: 1 }} />

        {!done ? (
          <VPrimary onClick={() => setScanning(true)} disabled={scanning}>
            {scanning ? 'Reading…' : 'Capture front →'}
          </VPrimary>
        ) : (
          <VPrimary onClick={() => go('verifySelfie')}>Continue to selfie →</VPrimary>
        )}
      </div>
    </div>
  );
}

// ── Verify Selfie Screen ────────────────────────────────────────────────
function ScreenVerifySelfie({ go }) {
  const [capturing, setCapturing] = useState(false);
  const [done, setDone] = useState(false);
  useEffect(() => {
    if (capturing) {
      const t = setTimeout(() => { setCapturing(false); setDone(true); setTimeout(() => go('verifySuccess'), 900); }, 1800);
      return () => clearTimeout(t);
    }
  }, [capturing]);

  return (
    <div style={{ position: 'relative', height: '100%', display: 'flex', flexDirection: 'column' }}>
      <VTopBar
        left={<button onClick={() => go('verifyId')} style={{ background: 'transparent', border: 0, padding: 0, cursor: 'pointer', color: 'var(--plum-soft)', fontSize: 18 }}>←</button>}
        right={<StepDots step={1} total={3} />}
      />
      <div style={{ flex: 1, padding: '12px 28px 30px', display: 'flex', flexDirection: 'column' }}>
        <div className="v-eyebrow" style={{ marginBottom: 12 }}>Step two of three</div>
        <h2 style={{ fontFamily: 'var(--serif)', fontSize: 32, lineHeight: 1.05, fontWeight: 400, color: 'var(--plum)', margin: 0 }}>
          A photo of <span style={{ fontStyle: 'italic', color: 'var(--rose)' }}>you</span>.
        </h2>
        <p style={{ fontFamily: 'var(--sans)', fontSize: 14, color: 'var(--plum-soft)', lineHeight: 1.55, marginTop: 12, fontWeight: 300 }}>
          We'll match your face to your ID. Look straight ahead, eyes open, no filters. This image is never stored.
        </p>

        {/* Selfie circle */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
          {/* outer petal ring */}
          <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', pointerEvents: 'none' }}>
            <div style={{
              width: 280, height: 280, borderRadius: '50%',
              border: '1px solid var(--blush)', position: 'absolute',
              animation: capturing ? 'vRing 1.8s ease-out' : 'none',
            }}/>
            <div style={{
              width: 320, height: 320, borderRadius: '50%',
              border: '1px solid var(--champagne)', position: 'absolute', opacity: 0.6,
            }}/>
          </div>
          <style>{`
            @keyframes vRing { 0% { transform: scale(0.9); opacity: 1 } 100% { transform: scale(1.6); opacity: 0 } }
            @keyframes vPulse { 0%, 100% { transform: scale(1); box-shadow: 0 0 0 0 rgba(217,137,124,0.5) } 50% { transform: scale(1.04); box-shadow: 0 0 0 18px rgba(217,137,124,0) } }
          `}</style>

          <div style={{
            width: 220, height: 220, borderRadius: '50%',
            background: 'linear-gradient(140deg, var(--ivory-warm), var(--blush-pale))',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: 'inset 0 0 0 1.5px var(--blush), 0 12px 40px rgba(217,137,124,0.18)',
            position: 'relative',
          }}>
            {!done ? (
              <svg width="80" height="80" viewBox="0 0 80 80" fill="none" opacity="0.5">
                <circle cx="40" cy="30" r="14" stroke="var(--plum)" strokeWidth="1.5"/>
                <path d="M14 70c4-12 12-18 26-18s22 6 26 18" stroke="var(--plum)" strokeWidth="1.5" strokeLinecap="round"/>
              </svg>
            ) : (
              <div style={{ width: 80, height: 80, borderRadius: '50%', background: 'var(--sage)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <svg width="32" height="32" viewBox="0 0 22 22" fill="none"><path d="M4 11l5 5 9-11" stroke="var(--ivory)" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"/></svg>
              </div>
            )}
          </div>

          {capturing && (
            <div style={{ marginTop: 28, fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 17, color: 'var(--plum)' }}>
              Matching face to ID…
            </div>
          )}
        </div>

        {!done && (
          <button onClick={() => setCapturing(true)} disabled={capturing}
            style={{
              alignSelf: 'center', width: 76, height: 76, borderRadius: '50%',
              border: '3px solid var(--plum)', background: 'var(--ivory)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              cursor: capturing ? 'wait' : 'pointer', padding: 0, marginBottom: 8,
              animation: capturing ? 'none' : 'vPulse 2s ease-in-out infinite',
            }}>
            <div style={{ width: 56, height: 56, borderRadius: '50%', background: 'var(--rose)' }}/>
          </button>
        )}
        <div style={{ textAlign: 'center', fontFamily: 'var(--sans)', fontSize: 12, color: 'var(--mauve-deep)', letterSpacing: 0.3 }}>
          Tap to capture
        </div>
      </div>
    </div>
  );
}

// ── Verify Success ──────────────────────────────────────────────────────
function ScreenVerifySuccess({ go }) {
  return (
    <div style={{ position: 'relative', height: '100%', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      {/* Celebration blooms */}
      <div style={{ position: 'absolute', top: 80, left: -40, width: 220, height: 220,
        background: 'radial-gradient(circle, var(--blush) 0%, transparent 65%)', opacity: 0.7,
        animation: 'vFloat1 8s ease-in-out infinite' }} />
      <div style={{ position: 'absolute', top: 200, right: -60, width: 240, height: 240,
        background: 'radial-gradient(circle, var(--champagne) 0%, transparent 70%)', opacity: 0.6,
        animation: 'vFloat2 10s ease-in-out infinite' }} />
      <div style={{ position: 'absolute', bottom: 120, left: -50, width: 200, height: 200,
        background: 'radial-gradient(circle, var(--sage-pale) 0%, transparent 70%)', opacity: 0.7,
        animation: 'vFloat1 12s ease-in-out infinite reverse' }} />

      <style>{`
        @keyframes vFloat1 { 0%, 100% { transform: translate(0,0) } 50% { transform: translate(20px, -15px) } }
        @keyframes vFloat2 { 0%, 100% { transform: translate(0,0) } 50% { transform: translate(-15px, 20px) } }
        @keyframes vFadeUp { 0% { opacity: 0; transform: translateY(20px) } 100% { opacity: 1; transform: translateY(0) } }
        @keyframes vBloom { 0% { opacity: 0; transform: scale(0.6) } 100% { opacity: 1; transform: scale(1) } }
        .v-fade-up { animation: vFadeUp .7s cubic-bezier(.2,.7,.3,1) both; }
        .v-bloom { animation: vBloom .8s cubic-bezier(.3,1.4,.4,1) both; }
      `}</style>

      <VTopBar />

      <div style={{ flex: 1, padding: '0 28px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center', position: 'relative', zIndex: 1 }}>
        <div className="v-bloom">
          <Floret size={56} color="var(--rose)" center="var(--ivory)" />
        </div>

        <div className="v-fade-up" style={{ animationDelay: '.2s' }}>
          <span className="v-sticker" style={{ marginTop: 24, marginBottom: 16, background: 'var(--sage-pale)', color: 'var(--sage-deep)' }}>
            <Sparkle size={10} color="var(--sage-deep)" /> verified · member #47,232
          </span>
        </div>

        <h2 className="v-fade-up" style={{
          fontFamily: 'var(--serif)', fontSize: 56, lineHeight: 0.95, fontWeight: 400,
          color: 'var(--plum)', margin: '12px 0 0', animationDelay: '.3s', textWrap: 'balance',
        }}>
          You're <span style={{ fontStyle: 'italic', color: 'var(--rose)' }}>in</span>.
        </h2>

        <p className="v-fade-up" style={{
          fontFamily: 'var(--sans)', fontSize: 15, color: 'var(--plum-soft)', lineHeight: 1.55,
          marginTop: 20, maxWidth: 280, fontWeight: 300, animationDelay: '.5s',
        }}>
          You'll never have to do that again. Welcome to a quieter way of dating — informed, deliberate, on your terms.
        </p>
      </div>

      <div className="v-fade-up" style={{ padding: '0 28px 30px', position: 'relative', zIndex: 1, animationDelay: '.7s' }}>
        <VPrimary onClick={() => go('search')}>
          Run your first search →
        </VPrimary>
      </div>
    </div>
  );
}

// ── Search Screen ───────────────────────────────────────────────────────
function ScreenSearch({ go, state, set }) {
  const [phone, setPhone] = useState(state.phone || '(415) 555-0142');
  const [name, setName] = useState(state.name || 'Marcus Anderson');

  return (
    <div style={{ position: 'relative', height: '100%', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', top: -30, right: -80, width: 220, height: 220,
        background: 'radial-gradient(circle, var(--blush-pale) 0%, transparent 70%)', opacity: 0.7 }} />

      <VTopBar
        right={
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '4px 10px', borderRadius: 'var(--r-pill)', background: 'var(--sage-pale)' }}>
            <div style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--sage-deep)' }}/>
            <span style={{ fontFamily: 'var(--sans)', fontSize: 11, color: 'var(--sage-deep)', letterSpacing: 0.3, fontWeight: 500 }}>Verified</span>
          </div>
        }
      />

      <div style={{ flex: 1, padding: '12px 28px 24px', display: 'flex', flexDirection: 'column', position: 'relative', zIndex: 1 }}>
        <div className="v-eyebrow" style={{ marginBottom: 12 }}>New search</div>
        <h2 style={{
          fontFamily: 'var(--serif)', fontSize: 38, lineHeight: 1.02, fontWeight: 400, color: 'var(--plum)', margin: 0, letterSpacing: -0.2,
        }}>
          Who would <span style={{ fontStyle: 'italic', color: 'var(--rose)' }}>you</span><br/>
          like to know?
        </h2>
        <p style={{ fontFamily: 'var(--sans)', fontSize: 14, color: 'var(--plum-soft)', lineHeight: 1.55, marginTop: 14, fontWeight: 300 }}>
          His number is the only thing we truly need. A name sharpens the picture.
        </p>

        {/* Form */}
        <div style={{ marginTop: 30, display: 'flex', flexDirection: 'column', gap: 16 }}>
          <Field label="His number" required>
            <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="(•••) ••• ••••"
              style={{
                width: '100%', border: 'none', background: 'transparent', outline: 'none',
                fontFamily: 'var(--serif)', fontSize: 24, color: 'var(--plum)', padding: '6px 0',
                fontVariantNumeric: 'tabular-nums', letterSpacing: 0.3,
              }} />
          </Field>

          <Field label="His name" sub="optional, helps us cross-reference">
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="First & last"
              style={{
                width: '100%', border: 'none', background: 'transparent', outline: 'none',
                fontFamily: 'var(--serif)', fontSize: 22, fontStyle: 'italic', color: 'var(--plum)', padding: '6px 0',
              }} />
          </Field>

          <div style={{
            display: 'flex', alignItems: 'center', gap: 10, marginTop: 4,
            padding: '12px 16px', borderRadius: 'var(--r-md)', background: 'var(--ivory-warm)',
          }}>
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path d="M8 1L2 4v4c0 4 6 7 6 7s6-3 6-7V4l-6-3z" stroke="var(--plum-soft)" strokeWidth="1.3" strokeLinejoin="round"/>
              <path d="M5.5 8l2 2 3-4" stroke="var(--plum-soft)" strokeWidth="1.3" strokeLinecap="round"/>
            </svg>
            <div style={{ fontFamily: 'var(--sans)', fontSize: 12, color: 'var(--plum-soft)', lineHeight: 1.4 }}>
              Searches are private. <span style={{ fontStyle: 'italic', fontFamily: 'var(--serif)', fontSize: 13 }}>He'll never know.</span>
            </div>
          </div>
        </div>

        <div style={{ flex: 1 }} />

        {/* Recent — implies repeat use */}
        <div style={{ marginBottom: 18 }}>
          <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 10 }}>
            <div className="v-eyebrow" style={{ fontSize: 10 }}>Recent · last 30 days</div>
            <button onClick={() => go('compare')} style={{
              background: 'transparent', border: 0, padding: 0, cursor: 'pointer',
              fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 13, color: 'var(--rose)', whiteSpace: 'nowrap',
            }}>
              compare them →
            </button>
          </div>
          <div style={{ display: 'flex', gap: 8, overflowX: 'auto' }}>
            {[
              { n: 'Marcus A.', d: '2d', c: 'var(--honey)' },
              { n: 'Tom B.', d: '11d', c: 'var(--sage)' },
              { n: 'Greg P.', d: '23d', c: 'var(--deeprose)' },
            ].map((x, i) => (
              <div key={i} style={{
                display: 'flex', alignItems: 'center', gap: 8, padding: '8px 12px',
                borderRadius: 'var(--r-pill)', background: 'var(--pearl)', boxShadow: 'var(--shadow-xs)',
                flexShrink: 0,
              }}>
                <div style={{ width: 8, height: 8, borderRadius: '50%', background: x.c, flexShrink: 0 }}/>
                <span style={{ fontFamily: 'var(--sans)', fontSize: 12.5, color: 'var(--plum)', whiteSpace: 'nowrap' }}>{x.n}</span>
                <span style={{ fontFamily: 'var(--sans)', fontSize: 11, color: 'var(--mauve-deep)', whiteSpace: 'nowrap' }}>{x.d}</span>
              </div>
            ))}
          </div>
        </div>

        <VPrimary onClick={() => { set({ phone, name }); go('loading'); }} disabled={!phone}>
          Get the report →
        </VPrimary>
        <div style={{ textAlign: 'center', marginTop: 10, fontFamily: 'var(--sans)', fontSize: 11, color: 'var(--mauve-deep)', whiteSpace: 'nowrap' }}>
          1 of 3 searches this week · <span style={{ textDecoration: 'underline' }}>upgrade for unlimited</span>
        </div>
      </div>
    </div>
  );
}

function Field({ label, sub, required, children }) {
  return (
    <div style={{
      padding: '14px 18px 12px', borderRadius: 'var(--r-lg)',
      background: 'var(--pearl)', boxShadow: 'var(--shadow-sm)',
      border: '1px solid rgba(232, 213, 183, 0.4)',
    }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 2 }}>
        <span className="v-eyebrow" style={{ fontSize: 10, color: 'var(--wine)', whiteSpace: 'nowrap' }}>{label}</span>
        {required && <span style={{ color: 'var(--rose)', fontSize: 10 }}>•</span>}
        {sub && <span style={{ fontFamily: 'var(--sans)', fontSize: 10.5, color: 'var(--mauve-deep)', fontStyle: 'italic', marginLeft: 'auto', whiteSpace: 'nowrap' }}>{sub}</span>}
      </div>
      {children}
    </div>
  );
}

// ── Loading Screen ──────────────────────────────────────────────────────
function ScreenLoading({ go, state }) {
  const stages = [
    'Reaching the carrier…',
    'Cross-referencing identity…',
    'Pulling property records…',
    'Checking public filings…',
    'Scanning social footprint…',
    'Sealing the envelope…',
  ];
  const [stage, setStage] = useState(0);
  useEffect(() => {
    const ticks = stages.map((_, i) => setTimeout(() => setStage(i), i * 650));
    const done = setTimeout(() => go('report'), stages.length * 650 + 400);
    return () => { ticks.forEach(clearTimeout); clearTimeout(done); };
  }, []);

  return (
    <div style={{ position: 'relative', height: '100%', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      {/* Floating blooms */}
      {[
        { top: 60, left: -50, c: 'var(--blush)', dur: 9, delay: 0 },
        { top: 200, right: -70, c: 'var(--champagne)', dur: 11, delay: 1 },
        { bottom: 250, left: -40, c: 'var(--blush-pale)', dur: 13, delay: 2 },
        { bottom: 80, right: -50, c: 'var(--mauve)', dur: 10, delay: 3 },
      ].map((b, i) => (
        <div key={i} style={{
          position: 'absolute',
          top: b.top, left: b.left, right: b.right, bottom: b.bottom,
          width: 180, height: 180, borderRadius: '50%',
          background: `radial-gradient(circle, ${b.c} 0%, transparent 70%)`,
          opacity: 0.5,
          animation: `vDrift${i} ${b.dur}s ease-in-out ${b.delay}s infinite`,
        }} />
      ))}

      <style>{`
        @keyframes vDrift0 { 0%, 100% { transform: translate(0, 0) scale(1) } 50% { transform: translate(30px, 20px) scale(1.1) } }
        @keyframes vDrift1 { 0%, 100% { transform: translate(0, 0) scale(1) } 50% { transform: translate(-25px, 30px) scale(1.05) } }
        @keyframes vDrift2 { 0%, 100% { transform: translate(0, 0) scale(1) } 50% { transform: translate(40px, -20px) scale(1.1) } }
        @keyframes vDrift3 { 0%, 100% { transform: translate(0, 0) scale(1) } 50% { transform: translate(-30px, -25px) scale(0.95) } }
        @keyframes vSpinPetal { from { transform: rotate(0deg) } to { transform: rotate(360deg) } }
        @keyframes vShimmer { 0% { background-position: -200% 0 } 100% { background-position: 200% 0 } }
      `}</style>

      <VTopBar />

      <div style={{ flex: 1, padding: '0 28px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center', position: 'relative', zIndex: 1 }}>

        {/* Rotating petal arrangement */}
        <div style={{ position: 'relative', width: 160, height: 160, animation: 'vSpinPetal 12s linear infinite' }}>
          {[0, 60, 120, 180, 240, 300].map((deg, i) => (
            <div key={i} style={{
              position: 'absolute', top: '50%', left: '50%',
              transform: `translate(-50%, -50%) rotate(${deg}deg) translateY(-46px)`,
              width: 20, height: 50, borderRadius: '50%',
              background: `radial-gradient(circle at 50% 100%, ${['var(--rose)', 'var(--blush-deep)', 'var(--champagne)'][i % 3]}, var(--blush-pale))`,
              opacity: 0.7,
            }}/>
          ))}
          <div style={{
            position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)',
            width: 30, height: 30, borderRadius: '50%', background: 'var(--rose)',
          }}/>
        </div>

        <div style={{ marginTop: 36 }}>
          <span className="v-eyebrow" style={{ color: 'var(--mauve-deep)' }}>Gathering intelligence</span>
        </div>

        <h2 style={{
          fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 26, fontWeight: 400,
          color: 'var(--plum)', margin: '12px 0 0', minHeight: 60, transition: 'opacity .3s', textWrap: 'balance',
        }} key={stage}>
          {stages[stage]}
        </h2>

        {/* Progress dots */}
        <div style={{ marginTop: 24, display: 'flex', gap: 6 }}>
          {stages.map((_, i) => (
            <div key={i} style={{
              width: 6, height: 6, borderRadius: '50%',
              background: i <= stage ? 'var(--rose)' : 'var(--ivory-deep)',
              transition: 'background .3s',
            }}/>
          ))}
        </div>

        <div style={{ marginTop: 30, fontFamily: 'var(--sans)', fontSize: 12.5, color: 'var(--mauve-deep)', maxWidth: 240, lineHeight: 1.5 }}>
          We're checking <span style={{ fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 14 }}>seven independent sources</span>. This usually takes 15-20 seconds.
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  ScreenLanding, ScreenVerifyIntro, ScreenVerifyId, ScreenVerifySelfie,
  ScreenVerifySuccess, ScreenSearch, ScreenLoading,
  VPrimary, VSecondary, VTopBar, StepDots, Field,
});
