// petals.jsx — decorative petal/floral SVG motifs for Verity
// Keep these simple — circles, ellipses, soft curves. No complicated illustration.

const Petal = ({ size = 24, color = 'var(--blush)', rotate = 0, style = {} }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" style={{ transform: `rotate(${rotate}deg)`, ...style }}>
    <ellipse cx="12" cy="12" rx="5" ry="11" fill={color} />
  </svg>
);

// A small 4-petal floret
const Floret = ({ size = 32, color = 'var(--blush)', center = 'var(--champagne)', style = {} }) => (
  <svg width={size} height={size} viewBox="0 0 32 32" style={style}>
    <ellipse cx="16" cy="6" rx="3.5" ry="7" fill={color} opacity="0.9"/>
    <ellipse cx="16" cy="26" rx="3.5" ry="7" fill={color} opacity="0.9"/>
    <ellipse cx="6" cy="16" rx="7" ry="3.5" fill={color} opacity="0.9"/>
    <ellipse cx="26" cy="16" rx="7" ry="3.5" fill={color} opacity="0.9"/>
    <circle cx="16" cy="16" r="3" fill={center} />
  </svg>
);

// A soft offset double-circle bloom (Glossier-y)
const Bloom = ({ size = 80, c1 = 'var(--blush)', c2 = 'var(--blush-pale)', style = {} }) => (
  <svg width={size} height={size} viewBox="0 0 80 80" style={style}>
    <circle cx="32" cy="32" r="28" fill={c1} opacity="0.85"/>
    <circle cx="50" cy="46" r="22" fill={c2} opacity="0.85" style={{ mixBlendMode: 'multiply' }}/>
  </svg>
);

// Sparkle — 4-point star
const Sparkle = ({ size = 14, color = 'var(--rose)', style = {} }) => (
  <svg width={size} height={size} viewBox="0 0 14 14" style={style}>
    <path d="M7 0 L8 6 L14 7 L8 8 L7 14 L6 8 L0 7 L6 6 Z" fill={color} />
  </svg>
);

// V monogram for Verity logo
const VMark = ({ size = 28, color = 'var(--plum)', style = {} }) => (
  <svg width={size} height={size} viewBox="0 0 28 28" style={style}>
    <path d="M3 4 L14 24 L25 4" fill="none" stroke={color} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
    <circle cx="14" cy="24" r="1.4" fill={color}/>
  </svg>
);

// Wordmark - Verity in italic serif logo style
const Wordmark = ({ size = 32, color = 'var(--plum)', style = {} }) => (
  <span className="v-logo" style={{
    fontSize: size,
    fontFamily: 'Italiana, "Cormorant Garamond", serif',
    color, letterSpacing: '0.08em',
    fontWeight: 400, lineHeight: 1,
    ...style,
  }}>VERITY</span>
);

// Soft signature curve underline (decorative)
const Swoosh = ({ width = 80, color = 'var(--rose)', style = {} }) => (
  <svg width={width} height={width / 4} viewBox="0 0 80 20" style={style} fill="none">
    <path d="M2 12 Q 20 4, 40 10 T 78 8" stroke={color} strokeWidth="1.5" strokeLinecap="round"/>
  </svg>
);

// Soft handwritten arrow (for "Hey You!" sticker-like)
const HandArrow = ({ size = 40, color = 'var(--rose)', style = {} }) => (
  <svg width={size} height={size} viewBox="0 0 40 40" style={style} fill="none">
    <path d="M5 8 Q 18 4, 28 18 T 32 32" stroke={color} strokeWidth="1.5" strokeLinecap="round"/>
    <path d="M26 28 L 32 32 L 30 25" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

// Decorative dotted divider
const DotDivider = ({ width = 120, color = 'var(--mauve)', style = {} }) => (
  <svg width={width} height="6" viewBox={`0 0 ${width} 6`} style={style}>
    {Array.from({ length: Math.floor(width / 8) }).map((_, i) => (
      <circle key={i} cx={i * 8 + 4} cy="3" r="1" fill={color} opacity="0.5"/>
    ))}
  </svg>
);

Object.assign(window, { Petal, Floret, Bloom, Sparkle, VMark, Wordmark, Swoosh, HandArrow, DotDivider });
