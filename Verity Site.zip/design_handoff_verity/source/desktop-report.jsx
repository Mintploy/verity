// desktop-report.jsx — Verity desktop report view

const { useState: useStateDR } = React;

function DesktopReport({ onBack, onCompare }) {
  const t = window.__verityScore || 'yellow';
  const persona = window.PERSONAS[t];

  return (
    <div data-screen-label="Verity Desktop / Report" style={{ background: 'var(--ivory)', minHeight: '100vh' }}>
      <VNav onSearch={onBack} />

      <div style={{ display: 'grid', gridTemplateColumns: '280px 1fr 320px', gap: 32, padding: '40px 56px 80px', maxWidth: 1480, margin: '0 auto' }}>

        {/* LEFT SIDEBAR */}
        <aside style={{ position: 'sticky', top: 92, height: 'fit-content', display: 'flex', flexDirection: 'column', gap: 20 }}>
          <button onClick={onBack} style={{
            display: 'flex', alignItems: 'center', gap: 8, padding: '10px 16px',
            border: 0, background: 'transparent', cursor: 'pointer', alignSelf: 'flex-start',
            fontFamily: 'var(--sans)', fontSize: 13, color: 'var(--plum-soft)',
          }}>
            ← New search
          </button>

          <div style={{
            padding: 18, borderRadius: 'var(--r-lg)', background: 'var(--pearl)', boxShadow: 'var(--shadow-sm)',
          }}>
            <div className="v-eyebrow" style={{ marginBottom: 10 }}>Jump to</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
              {[
                'Safety score',
                'Phone intelligence',
                'Identity',
                'Address history',
                'Relationships',
                'Professional',
                'Public records',
                'Social footprint',
                'Recommendations',
              ].map((s, i) => (
                <a key={i} href={`#sec-${i}`} style={{
                  fontFamily: 'var(--sans)', fontSize: 13, color: 'var(--plum-soft)',
                  textDecoration: 'none', padding: '8px 10px', borderRadius: 8,
                  display: 'flex', alignItems: 'center', gap: 10,
                }}>
                  <span style={{ width: 4, height: 4, borderRadius: '50%', background: 'var(--mauve)' }}/>
                  {s}
                </a>
              ))}
            </div>
          </div>

          <div style={{
            padding: 18, borderRadius: 'var(--r-lg)', background: 'var(--ivory-warm)',
          }}>
            <div className="v-eyebrow" style={{ marginBottom: 12 }}>Recent · last 30 days</div>
            {[
              { n: 'Marcus A.', d: '2d ago', c: 'var(--honey)' },
              { n: 'Tom B.', d: '11d ago', c: 'var(--sage)' },
              { n: 'Greg P.', d: '23d ago', c: 'var(--deeprose)' },
            ].map((x, i) => (
              <div key={i} style={{
                display: 'flex', alignItems: 'center', gap: 10, padding: '8px 0',
                borderTop: i ? '1px solid var(--ivory-deep)' : 'none',
              }}>
                <div style={{ width: 8, height: 8, borderRadius: '50%', background: x.c }}/>
                <span style={{ flex: 1, fontFamily: 'var(--sans)', fontSize: 13, color: 'var(--plum)' }}>{x.n}</span>
                <span style={{ fontFamily: 'var(--sans)', fontSize: 11, color: 'var(--mauve-deep)' }}>{x.d}</span>
              </div>
            ))}
          </div>
        </aside>

        {/* MAIN */}
        <main style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
          {/* Header strip */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 16 }}>
            <div>
              <span className="v-eyebrow">Verity report · VR-2026-04-12-7A3E</span>
              <h1 style={{
                fontFamily: 'var(--serif)', fontSize: 44, lineHeight: 1.05, fontWeight: 400,
                color: 'var(--plum)', margin: '6px 0 0', letterSpacing: -0.4,
              }}>
                <span style={{ fontStyle: 'italic', color: 'var(--rose)' }}>On</span>{' '}{persona.name}
              </h1>
            </div>
            <div style={{ fontFamily: 'var(--sans)', fontSize: 12.5, color: 'var(--mauve-deep)', textAlign: 'right' }}>
              Generated <span style={{ fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 14, color: 'var(--plum)' }}>just now</span><br/>
              94% confidence · 7 sources
            </div>
          </div>

          {/* Big score row */}
          <DesktopScoreBadge persona={persona} score={persona.score} />

          {/* Two-col grid for compact sections */}
          <div id="sec-1" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
            <DesktopSection eyebrow="01" title="Phone intelligence" icon={sectionIcons.phone}>
              <KVList rows={[
                ['Carrier', persona.carrier],
                ['Line type', persona.voip ? 'Mobile + VoIP secondary' : 'Mobile, single line'],
                ['Number age', persona.numberAge],
                ['Origin', persona.origin],
              ]}/>
              {persona.voip && (
                <FlagNote tone={persona.score === 'red' ? 'red' : 'yellow'}>
                  {persona.voip}
                </FlagNote>
              )}
            </DesktopSection>

            <DesktopSection id="sec-2" eyebrow="02" title="Identity signals" icon={sectionIcons.identity} accent="var(--ivory-warm)">
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
                <Stat label="Full name" value={persona.name}/>
                <Stat label="Age" value={persona.age}/>
                <Stat label="Date of birth" value={persona.dob}/>
                <Stat label="Verified by" value="3 sources"/>
              </div>
            </DesktopSection>
          </div>

          {/* Address history — full width */}
          <DesktopSection id="sec-3" eyebrow="03" title="Address history" icon={sectionIcons.address} accent="var(--blush-pale)">
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '14px 32px' }}>
              {persona.addresses.map((a, i) => (
                <div key={i} style={{
                  display: 'flex', alignItems: 'flex-start', gap: 14, padding: '12px 0',
                  borderTop: i >= 2 ? '1px solid var(--ivory-deep)' : 'none',
                }}>
                  <div style={{
                    width: 10, height: 10, borderRadius: '50%', marginTop: 8, flexShrink: 0,
                    background: a.flag ? 'var(--deeprose)' : a.current ? 'var(--rose)' : 'var(--mauve)',
                    boxShadow: a.current ? '0 0 0 3px var(--blush-pale)' : 'none',
                  }}/>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 2 }}>
                      <span style={{ fontFamily: 'var(--sans)', fontSize: 11, fontWeight: 500, color: 'var(--mauve-deep)', letterSpacing: 0.3 }}>{a.years}</span>
                      {a.current && <span style={{ fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 13, color: 'var(--rose)' }}>· current</span>}
                    </div>
                    <div style={{ fontFamily: 'var(--serif)', fontSize: 17, color: 'var(--plum)', lineHeight: 1.2 }}>{a.addr}</div>
                    <div style={{ fontFamily: 'var(--sans)', fontSize: 12.5, color: a.flag ? 'var(--deeprose-deep)' : 'var(--plum-soft)', marginTop: 4, fontWeight: a.flag ? 500 : 300 }}>
                      {a.detail}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </DesktopSection>

          {/* Two-col: relationships + professional */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
            <DesktopSection id="sec-4" eyebrow="04" title="Relationships" icon={sectionIcons.rel}>
              <Stat label="Status" value={persona.relationships.status} block/>
              {persona.relationships.spouse !== '—' && <Stat label="Spouse" value={persona.relationships.spouse} block/>}
              <Stat label="Prior marriages" value={persona.relationships.priors} block/>
              <SubLabel>Known relatives</SubLabel>
              <TagWrap items={persona.relationships.relatives}/>
              <SubLabel>Close associates</SubLabel>
              <TagWrap items={persona.relationships.associates}/>
            </DesktopSection>

            <DesktopSection id="sec-5" eyebrow="05" title="Professional" icon={sectionIcons.prof} accent="var(--ivory-warm)">
              <div style={{
                padding: '14px 16px', background: 'var(--ivory)', borderRadius: 'var(--r-md)', marginBottom: 14,
              }}>
                <div style={{ fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 18, color: 'var(--plum)', lineHeight: 1.2 }}>
                  {persona.professional.title}
                </div>
                <div style={{ fontFamily: 'var(--sans)', fontSize: 12.5, color: 'var(--plum-soft)', marginTop: 4 }}>
                  {persona.professional.company} · {persona.professional.tenure}
                </div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
                <Stat label="Est. income" value={persona.professional.income}/>
                <Stat label="Est. net worth" value={persona.professional.networth}/>
              </div>
              <SubLabel>Business entities</SubLabel>
              <div style={{ fontFamily: 'var(--sans)', fontSize: 13, color: 'var(--plum)', lineHeight: 1.5, fontWeight: 300 }}>
                {persona.professional.llcs}
              </div>
            </DesktopSection>
          </div>

          {/* Public records — full */}
          <DesktopSection id="sec-6" eyebrow="06" title="Public record flags" icon={sectionIcons.public} accent={persona.score === 'red' ? 'var(--deeprose-pale)' : 'var(--blush-pale)'}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '0 32px' }}>
              {persona.public.map((p, i) => (
                <div key={i} style={{
                  display: 'flex', alignItems: 'flex-start', gap: 12, padding: '14px 0',
                  borderTop: i >= 2 ? '1px solid var(--ivory-deep)' : 'none',
                }}>
                  <div style={{
                    width: 24, height: 24, borderRadius: '50%', flexShrink: 0, marginTop: 1,
                    background: p.good ? 'var(--sage-pale)' : p.flag ? 'var(--deeprose-pale)' : 'var(--ivory-warm)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                    {p.good && <svg width="12" height="12" viewBox="0 0 11 11"><path d="M2 6l2.5 2.5L9 3" stroke="var(--sage-deep)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" fill="none"/></svg>}
                    {p.flag && <svg width="12" height="12" viewBox="0 0 11 11"><path d="M5.5 2v3.5M5.5 8v0.5" stroke="var(--deeprose-deep)" strokeWidth="2" strokeLinecap="round"/></svg>}
                    {p.neutral && <div style={{ width: 5, height: 5, borderRadius: '50%', background: 'var(--mauve-deep)' }}/>}
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div className="v-eyebrow" style={{ fontSize: 10, marginBottom: 3 }}>{p.label}</div>
                    <div style={{
                      fontFamily: 'var(--sans)', fontSize: 13.5, lineHeight: 1.4,
                      color: p.flag ? 'var(--deeprose-deep)' : 'var(--plum)',
                      fontWeight: p.flag ? 500 : 300,
                    }}>{p.value}</div>
                  </div>
                </div>
              ))}
            </div>
          </DesktopSection>

          {/* Social */}
          <DesktopSection id="sec-7" eyebrow="07" title="Social footprint" icon={sectionIcons.social} accent="var(--ivory-warm)">
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.4fr', gap: 32 }}>
              <div>
                <SubLabel style={{ marginTop: 0 }}>Known handles</SubLabel>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  {persona.social.handles.map((h, i) => (
                    <div key={i} style={{
                      padding: '10px 14px', background: 'var(--ivory)', borderRadius: 'var(--r-md)',
                      fontFamily: 'var(--sans)', fontSize: 13, color: 'var(--plum)',
                    }}>{h}</div>
                  ))}
                </div>
              </div>
              <div>
                <SubLabel>Presence assessment</SubLabel>
                <div style={{ fontFamily: 'var(--sans)', fontSize: 13.5, color: 'var(--plum)', lineHeight: 1.6, fontWeight: 300 }}>
                  {persona.social.presence}
                </div>
                {persona.social.inconsistency !== 'None flagged.' && (
                  <FlagNote tone={persona.score === 'red' ? 'red' : 'yellow'}>
                    <strong style={{ fontWeight: 600 }}>Inconsistency: </strong>{persona.social.inconsistency}
                  </FlagNote>
                )}
              </div>
            </div>
          </DesktopSection>

          {/* Footer note */}
          <div style={{ textAlign: 'center', marginTop: 12, padding: '16px 0' }}>
            <DotDivider width={160} color="var(--mauve)"/>
            <div style={{
              marginTop: 14,
              fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 16, color: 'var(--plum-soft)',
              lineHeight: 1.5,
            }}>
              Verity does not predict the future.<br/>
              It tells you what's true today, so you can decide tomorrow.
            </div>
            <div style={{
              marginTop: 14,
              fontFamily: 'var(--sans)', fontSize: 11, color: 'var(--mauve-deep)', letterSpacing: 0.3, lineHeight: 1.6,
            }}>
              Sources: Whitepages Pro, ATTOM, BeenVerified, PACER, FEC, NSOPW, PDL<br/>
              <span style={{ textDecoration: 'underline' }}>Disclaimer</span> · <span style={{ textDecoration: 'underline' }}>Privacy</span> · <span style={{ textDecoration: 'underline' }}>How we score</span>
            </div>
          </div>
        </main>

        {/* RIGHT SIDEBAR — Recommendations + actions */}
        <aside style={{ position: 'sticky', top: 92, height: 'fit-content', display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div id="sec-8" style={{
            padding: '24px 22px', borderRadius: 'var(--r-lg)',
            background: 'linear-gradient(160deg, var(--primary-deep) 0%, var(--plum) 100%)',
            color: 'var(--ivory)', position: 'relative', overflow: 'hidden',
          }}>
            <div style={{
              position: 'absolute', top: -30, right: -30, width: 140, height: 140, borderRadius: '50%',
              background: 'radial-gradient(circle, var(--rose) 0%, transparent 65%)', opacity: 0.4,
            }}/>
            <div style={{ position: 'relative', zIndex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
                <Floret size={18} color="var(--blush)" center="var(--wine)"/>
                <div className="v-eyebrow" style={{ color: 'var(--blush)', fontSize: 10 }}>your move</div>
              </div>
              <h3 style={{
                fontFamily: 'var(--serif)', fontSize: 22, fontWeight: 400, lineHeight: 1.1,
                margin: 0, color: 'var(--ivory)',
              }}>
                What we'd <span style={{ fontStyle: 'italic', color: 'var(--blush)' }}>do next</span>.
              </h3>
              <div style={{ marginTop: 16, display: 'flex', flexDirection: 'column', gap: 12 }}>
                {persona.nextSteps.map((s, i) => (
                  <div key={i} style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                    <div style={{
                      fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 16,
                      color: 'var(--blush)', lineHeight: 1, flexShrink: 0, paddingTop: 2,
                      width: 18, textAlign: 'right',
                    }}>{String(i + 1).padStart(2, '0')}</div>
                    <div style={{
                      fontFamily: 'var(--sans)', fontSize: 12.5, color: 'var(--ivory)',
                      lineHeight: 1.5, opacity: 0.92, fontWeight: 300,
                    }}>{s}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Actions */}
          <div style={{
            padding: 18, borderRadius: 'var(--r-lg)', background: 'var(--pearl)', boxShadow: 'var(--shadow-sm)',
            display: 'flex', flexDirection: 'column', gap: 8,
          }}>
            <ActionBtn icon="compare" label="Compare with others" onClick={onCompare}/>
            <ActionBtn icon="dl" label="Download PDF"/>
            <ActionBtn icon="share" label="Share with your circle"/>
            <ActionBtn icon="bell" label="Re-run in 30 days"/>
            <ActionBtn icon="img" label="Reverse-image his photos"/>
          </div>

          <div style={{
            padding: 16, borderRadius: 'var(--r-lg)', background: 'var(--blush-pale)',
            fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 14, color: 'var(--wine)',
            lineHeight: 1.5, textAlign: 'center',
          }}>
            "Trust your gut. A clean report doesn't replace your read of him in person."
            <div style={{ fontFamily: 'var(--sans)', fontStyle: 'normal', fontSize: 10, color: 'var(--wine)', opacity: 0.7, marginTop: 8, letterSpacing: 0.3 }}>
              VERITY'S CARDINAL RULE
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

function ActionBtn({ icon, label, onClick }) {
  const icons = {
    dl: <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M7 1v8M3 6l4 4 4-4M2 12h10" stroke="var(--plum)" strokeWidth="1.4" strokeLinecap="round"/></svg>,
    share: <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><circle cx="3" cy="7" r="1.6" stroke="var(--plum)" strokeWidth="1.3"/><circle cx="11" cy="3" r="1.6" stroke="var(--plum)" strokeWidth="1.3"/><circle cx="11" cy="11" r="1.6" stroke="var(--plum)" strokeWidth="1.3"/><path d="M4.5 6.2l5-2.4M4.5 7.8l5 2.4" stroke="var(--plum)" strokeWidth="1.3"/></svg>,
    bell: <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M3 11V7a4 4 0 0 1 8 0v4M2 11h10M6 13h2" stroke="var(--plum)" strokeWidth="1.4" strokeLinecap="round"/></svg>,
    img: <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><rect x="1.5" y="2" width="11" height="9" rx="1.5" stroke="var(--plum)" strokeWidth="1.3"/><circle cx="4.5" cy="5" r="1" fill="var(--plum)"/><path d="M2 9l3-2.5 3 2 4-3" stroke="var(--plum)" strokeWidth="1.3" fill="none"/></svg>,
    compare: <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M2 3h4M2 7h7M2 11h10" stroke="var(--plum)" strokeWidth="1.4" strokeLinecap="round"/></svg>,
  };
  return (
    <button onClick={onClick} style={{
      display: 'flex', alignItems: 'center', gap: 12, padding: '10px 12px',
      border: 0, background: 'transparent', cursor: 'pointer',
      borderRadius: 8, textAlign: 'left',
      fontFamily: 'var(--sans)', fontSize: 13, color: 'var(--plum)',
    }}>
      {icons[icon]}
      <span>{label}</span>
      <span style={{ marginLeft: 'auto', color: 'var(--mauve)' }}>→</span>
    </button>
  );
}

// Desktop score badge — wider layout
function DesktopScoreBadge({ persona, score }) {
  const config = {
    green: { label: 'Green light', sub: 'Proceed with ease.', bg: 'var(--sage-pale)', deep: 'var(--sage-deep)', accent: 'var(--sage)', glow: 'rgba(155, 176, 152, 0.35)' },
    yellow: { label: 'Soft yellow', sub: 'Worth a slower pace.', bg: 'var(--honey-pale)', deep: 'var(--honey-deep)', accent: 'var(--honey)', glow: 'rgba(217, 179, 112, 0.35)' },
    red: { label: 'Deep rose', sub: 'We\'d skip this one.', bg: 'var(--deeprose-pale)', deep: 'var(--deeprose-deep)', accent: 'var(--deeprose)', glow: 'rgba(201, 122, 133, 0.35)' },
  }[score];

  const initials = persona.name.split(' ').map(n => n[0]).join('');

  return (
    <div id="sec-0" style={{
      display: 'grid', gridTemplateColumns: '1.2fr 1.8fr', gap: 0,
      borderRadius: 'var(--r-xl)', overflow: 'hidden',
      boxShadow: `0 16px 50px ${config.glow}, 0 2px 6px rgba(61,36,52,0.06)`,
    }}>
      {/* Left: huge score */}
      <div style={{
        padding: '36px 36px 32px', background: config.bg,
        position: 'relative', overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute', top: -60, right: -60, width: 240, height: 240, borderRadius: '50%',
          background: `radial-gradient(circle, ${config.accent} 0%, transparent 65%)`, opacity: 0.55,
        }}/>
        <div style={{ position: 'relative', zIndex: 1, height: '100%', display: 'flex', flexDirection: 'column' }}>
          <div className="v-eyebrow" style={{ color: config.deep, marginBottom: 16 }}>Safety score · live</div>
          <div style={{
            fontFamily: 'var(--serif)', fontSize: 80, fontWeight: 400,
            color: config.deep, lineHeight: 0.95, letterSpacing: -1,
          }}>
            {config.label.split(' ')[0]}<br/>
            <span style={{ fontStyle: 'italic', fontWeight: 300 }}>{config.label.split(' ')[1]}</span>
          </div>
          <div style={{ fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 20, color: config.deep, opacity: 0.8, marginTop: 12 }}>
            {config.sub}
          </div>

          <div style={{ flex: 1 }}/>

          {/* Subject quick row */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginTop: 28, paddingTop: 20, borderTop: `1px solid ${config.deep}22` }}>
            <div style={{
              width: 52, height: 52, borderRadius: '50%',
              background: `linear-gradient(135deg, var(--ivory-warm), var(--champagne))`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 20, color: 'var(--plum-soft)',
              boxShadow: `0 0 0 3px ${config.bg}, 0 0 0 4px ${config.deep}33`,
            }}>{initials}</div>
            <div>
              <div style={{ fontFamily: 'var(--serif)', fontSize: 20, color: config.deep, lineHeight: 1.1 }}>{persona.name}</div>
              <div style={{ fontFamily: 'var(--sans)', fontSize: 12, color: config.deep, opacity: 0.7, marginTop: 2 }}>Age {persona.age} · {persona.phoneInput}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Right: headline + summary */}
      <div style={{ padding: '36px 36px 32px', background: 'var(--pearl)', display: 'flex', flexDirection: 'column' }}>
        <div className="v-eyebrow" style={{ marginBottom: 16 }}>Verity's verdict</div>
        <div style={{
          fontFamily: 'var(--serif)', fontSize: 36, fontWeight: 400, lineHeight: 1.1, color: 'var(--plum)',
          fontStyle: 'italic', letterSpacing: -0.3, textWrap: 'balance',
        }}>
          "{persona.headline}"
        </div>
        <p style={{ fontFamily: 'var(--sans)', fontSize: 15, lineHeight: 1.65, color: 'var(--plum)', margin: '20px 0 0', fontWeight: 300 }}>
          {persona.summary}
        </p>
        <div style={{ flex: 1 }}/>
        <div style={{
          marginTop: 24, display: 'flex', gap: 24, fontFamily: 'var(--sans)', fontSize: 11, color: 'var(--plum-soft)', letterSpacing: 0.3,
        }}>
          <span><span style={{ opacity: 0.6 }}>CONFIDENCE</span> 94%</span>
          <span><span style={{ opacity: 0.6 }}>SOURCES</span> 7</span>
          <span><span style={{ opacity: 0.6 }}>GENERATED</span> JUST NOW</span>
        </div>
      </div>
    </div>
  );
}

// Desktop section wrapper — same as mobile but wider padding
function DesktopSection({ id, eyebrow, title, icon, children, accent = 'var(--blush-pale)' }) {
  return (
    <div id={id} style={{
      borderRadius: 'var(--r-lg)', background: 'var(--pearl)', boxShadow: 'var(--shadow-sm)',
      overflow: 'hidden',
    }}>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 14,
        padding: '24px 28px 18px',
      }}>
        <div style={{
          width: 42, height: 42, borderRadius: '50%',
          background: accent, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
        }}>{icon}</div>
        <div style={{ flex: 1 }}>
          <div className="v-eyebrow" style={{ fontSize: 10, marginBottom: 2 }}>Section {eyebrow}</div>
          <div style={{ fontFamily: 'var(--serif)', fontSize: 26, color: 'var(--plum)', lineHeight: 1.1, fontWeight: 400 }}>
            {title}
          </div>
        </div>
      </div>
      <div style={{ padding: '0 28px 24px' }}>
        {children}
      </div>
    </div>
  );
}

Object.assign(window, { DesktopReport, DesktopScoreBadge, DesktopSection, ActionBtn });
